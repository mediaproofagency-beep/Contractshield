# ⛨ ContractShield

> **Analyse IA de contrats — Détection de clauses abusives en quelques secondes.**

ContractShield est une application SaaS qui analyse vos contrats (PDF, DOCX, images) grâce à l'intelligence artificielle pour détecter les clauses abusives, calculer un score de risque, et proposer des suggestions de reformulation avec références juridiques.

---

## 🚀 Démarrage rapide

### Prérequis

- **Node.js** ≥ 18
- **npm** ≥ 9

### Installation

```bash
# 1. Cloner le projet
git clone https://github.com/votre-username/contractshield.git
cd contractshield

# 2. Installer les dépendances
npm install

# 3. Copier les variables d'environnement
cp .env.example .env

# 4. Lancer en développement
npm run dev
```

L'app démarre sur [http://localhost:3000](http://localhost:3000).

> **💡 Mode démo :** L'app fonctionne immédiatement sans configuration. Les paiements sont simulés et l'authentification utilise localStorage.

---

## 📁 Structure du projet

```
contractshield/
├── public/
│   └── favicon.svg                  # Icône du site
├── src/
│   ├── api/
│   │   └── mockBackend.js           # Backend simulé (analyse, auth, historique)
│   ├── components/
│   │   ├── common/
│   │   │   ├── ScoreRing.jsx        # Jauge circulaire de score animée
│   │   │   ├── RiskBadge.jsx        # Badge de niveau de risque
│   │   │   └── LoadingSpinner.jsx   # Spinner de chargement
│   │   ├── layout/
│   │   │   ├── Header.jsx           # Navigation principale responsive
│   │   │   └── Footer.jsx           # Pied de page
│   │   ├── UploadZone.jsx           # Drag & drop de fichiers
│   │   ├── AnalyzingAnimation.jsx   # Animation de scan IA
│   │   ├── ClauseCard.jsx           # Carte dépliable de clause
│   │   └── AnalysisReport.jsx       # Rapport complet d'analyse
│   ├── pages/
│   │   ├── Home.jsx                 # Landing page
│   │   ├── Analyze.jsx              # Page d'upload + analyse
│   │   ├── History.jsx              # Historique des analyses
│   │   ├── Pricing.jsx              # Tarifs + checkout Stripe
│   │   └── Auth.jsx                 # Connexion / Inscription
│   ├── context/
│   │   └── AuthContext.jsx          # Provider d'authentification
│   ├── hooks/
│   │   └── useAnalysis.js           # Hook de gestion d'analyse
│   ├── styles/
│   │   ├── theme.js                 # Design tokens & couleurs
│   │   ├── global.css               # Styles globaux & utilitaires
│   │   └── animations.css           # Bibliothèque d'animations CSS
│   ├── data/
│   │   ├── mockAnalyses.js          # Données de démo (clauses, rapports)
│   │   └── plans.js                 # Plans d'abonnement
│   ├── utils/
│   │   ├── stripe.js                # Intégration Stripe + simulation
│   │   └── fileValidation.js        # Validation de fichiers uploadés
│   ├── App.jsx                      # Routing & layout principal
│   └── main.jsx                     # Point d'entrée React
├── __tests__/
│   └── mockBackend.test.js          # Tests unitaires
├── index.html                       # HTML template
├── package.json
├── vite.config.js                   # Configuration Vite
├── vercel.json                      # Configuration Vercel
├── .env.example                     # Template des variables d'env
└── README.md
```

---

## ⚙️ Configuration

### Variables d'environnement

Créez un fichier `.env` à la racine (voir `.env.example`) :

```env
# Stripe (mode test)
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_XXXXXXXX

# Stripe Price IDs
VITE_STRIPE_PRICE_STARTER=price_XXXXXXXX
VITE_STRIPE_PRICE_PRO=price_XXXXXXXX
VITE_STRIPE_PRICE_ENTERPRISE=price_XXXXXXXX
```

> **Sans clé Stripe**, l'app fonctionne en mode simulation (les abonnements sont enregistrés localement).

### Configuration Stripe

1. Créez un compte sur [stripe.com](https://stripe.com)
2. Allez dans **Developers → API keys** → Copiez la clé publique `pk_test_...`
3. Créez 3 produits dans **Products** :
   - **Starter** → Prix : 29€/mois (récurrent)
   - **Professional** → Prix : 89€/mois (récurrent)
   - **Enterprise** → Prix : 299€/mois (récurrent)
4. Copiez les Price IDs (`price_...`) dans votre `.env`

### Configuration Firebase (optionnel)

Pour remplacer l'auth simulée par Firebase :

1. Créez un projet sur [Firebase Console](https://console.firebase.google.com)
2. Activez **Authentication → Email/Password**
3. Copiez les clés dans `.env`
4. Remplacez le code dans `AuthContext.jsx` par les SDK Firebase

---

## 🧪 Tests

```bash
# Lancer les tests
npm run test

# Lancer en mode watch
npm run test:watch
```

Les tests couvrent :
- Validation de fichiers (format, taille, intégrité)
- Analyse de contrats (score, clauses, stats)
- Calcul de score (labels, seuils)

---

## 🚢 Déploiement sur Vercel

### Méthode 1 : Via GitHub (recommandé)

1. Poussez votre code sur GitHub
2. Allez sur [vercel.com](https://vercel.com) → **New Project**
3. Importez votre repository
4. Ajoutez les variables d'environnement dans **Settings → Environment Variables**
5. Cliquez **Deploy**

### Méthode 2 : Via CLI

```bash
# Installer Vercel CLI
npm i -g vercel

# Déployer
vercel

# Déployer en production
vercel --prod
```

### Configuration Vercel

Le fichier `vercel.json` est déjà configuré pour :
- Réécriture SPA (toutes les routes → `index.html`)
- Cache optimisé pour les assets statiques

---

## 🏗️ Prochaines étapes (roadmap)

### Phase 2 — Backend réel
- [ ] API Node.js/Express (ou Serverless Functions Vercel)
- [ ] Extraction PDF réelle avec `pdf.js`
- [ ] Extraction DOCX avec `mammoth.js`
- [ ] OCR avec Tesseract pour les images
- [ ] Base de données PostgreSQL / Supabase

### Phase 3 — IA réelle
- [ ] Intégration Claude API / OpenAI pour l'analyse
- [ ] Fine-tuning sur le droit français
- [ ] Modèle de détection de clauses entraîné

### Phase 4 — Fonctionnalités avancées
- [ ] Comparaison de versions de contrat
- [ ] Génération de contre-propositions
- [ ] Templates de contrats sains
- [ ] API REST pour intégration tierce
- [ ] Multi-langues (EN, DE, ES)

---

## 📝 Scripts disponibles

| Commande | Description |
|----------|-------------|
| `npm run dev` | Lance le serveur de développement (port 3000) |
| `npm run build` | Build de production dans `dist/` |
| `npm run preview` | Prévisualise le build de production |
| `npm run test` | Lance les tests unitaires |
| `npm run test:watch` | Tests en mode watch |

---

## 🎨 Design System

Le thème est centralisé dans `src/styles/theme.js` :

| Token | Valeur | Usage |
|-------|--------|-------|
| `accent` | `#FF6B35` | Couleur principale (CTA, liens) |
| `danger` | `#FF4757` | Risque critique |
| `warning` | `#FFBE0B` | Risque moyen |
| `success` | `#06D6A0` | Risque faible, validations |
| `info` | `#4EA8DE` | Informations, tags |

Typographie :
- **Titres** : DM Serif Display
- **Corps** : DM Sans
- **Code** : JetBrains Mono

---

## 📄 Licence

Propriétaire — Tous droits réservés.

---

<p align="center">
  <strong>⛨ ContractShield</strong> — Ne signez plus à l'aveugle.
</p>
