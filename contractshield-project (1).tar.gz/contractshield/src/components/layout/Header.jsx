/**
 * Header — Navigation principale responsive
 */

import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import theme from '@/styles/theme';

const NAV_ITEMS = [
  { path: '/', label: 'Accueil' },
  { path: '/analyze', label: 'Analyser' },
  { path: '/history', label: 'Historique' },
  { path: '/pricing', label: 'Tarifs' },
];

export default function Header() {
  const { pathname } = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);

  return (
    <header
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '14px 24px',
        borderBottom: `1px solid ${theme.border}`,
        background: `${theme.bg}ee`,
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
      }}
    >
      {/* ── Logo ── */}
      <Link
        to="/"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 10,
          textDecoration: 'none',
          color: theme.text,
        }}
      >
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 9,
            background: `linear-gradient(135deg, ${theme.accent}, ${theme.accentDark})`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: 17,
            color: 'white',
          }}
        >
          ⛨
        </div>
        <span
          style={{
            fontFamily: theme.fontSerif,
            fontSize: 19,
            letterSpacing: -0.5,
          }}
        >
          ContractShield
        </span>
        <span
          className="tag"
          style={{
            background: theme.accentGlow,
            color: theme.accent,
            fontSize: 10,
          }}
        >
          BETA
        </span>
      </Link>

      {/* ── Nav desktop ── */}
      <nav
        style={{
          display: 'flex',
          gap: 4,
        }}
        className="desktop-nav"
      >
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            style={{
              padding: '8px 16px',
              borderRadius: 10,
              fontSize: 14,
              fontWeight: 500,
              textDecoration: 'none',
              transition: 'all 0.2s',
              color: pathname === item.path ? theme.accent : theme.textMuted,
              background:
                pathname === item.path ? theme.accentGlow : 'transparent',
            }}
          >
            {item.label}
          </Link>
        ))}
      </nav>

      {/* ── Actions droite ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {isAuthenticated ? (
          <>
            {/* Compteur d'analyses */}
            <div
              style={{
                fontFamily: theme.fontMono,
                fontSize: 12,
                color: theme.textDim,
                padding: '5px 10px',
                background: theme.surfaceAlt,
                borderRadius: 8,
              }}
              className="desktop-only"
            >
              {user.plan === 'enterprise'
                ? '∞ analyses'
                : `${user.analysesRemaining || 0} analyse(s)`}
            </div>

            {/* Avatar / Menu profil */}
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 9,
                  background: theme.surfaceAlt,
                  border: `1px solid ${theme.border}`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 13,
                  fontWeight: 600,
                  color: theme.accent,
                  cursor: 'pointer',
                  fontFamily: theme.fontSans,
                }}
              >
                {(user.name || user.email || 'U')[0].toUpperCase()}
              </button>

              {profileMenuOpen && (
                <div
                  style={{
                    position: 'absolute',
                    top: '100%',
                    right: 0,
                    marginTop: 8,
                    background: theme.surface,
                    border: `1px solid ${theme.border}`,
                    borderRadius: 12,
                    padding: 8,
                    minWidth: 200,
                    animation: 'fadeIn 0.2s ease-out',
                    zIndex: 100,
                  }}
                >
                  <div
                    style={{
                      padding: '10px 14px',
                      borderBottom: `1px solid ${theme.border}`,
                      marginBottom: 4,
                    }}
                  >
                    <div style={{ fontWeight: 600, fontSize: 14 }}>
                      {user.name || 'Utilisateur'}
                    </div>
                    <div
                      style={{
                        fontSize: 12,
                        color: theme.textDim,
                        marginTop: 2,
                      }}
                    >
                      {user.email}
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      logout();
                      setProfileMenuOpen(false);
                    }}
                    style={{
                      width: '100%',
                      padding: '8px 14px',
                      background: 'transparent',
                      border: 'none',
                      borderRadius: 8,
                      color: theme.danger,
                      fontSize: 14,
                      cursor: 'pointer',
                      textAlign: 'left',
                      fontFamily: theme.fontSans,
                    }}
                  >
                    Se déconnecter
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <Link to="/auth">
            <button className="btn-primary" style={{ padding: '8px 20px', fontSize: 13 }}>
              Connexion
            </button>
          </Link>
        )}

        {/* ── Burger mobile ── */}
        <button
          className="mobile-only"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          style={{
            display: 'none',
            background: 'none',
            border: 'none',
            color: theme.text,
            fontSize: 22,
            cursor: 'pointer',
            padding: 4,
          }}
        >
          {mobileMenuOpen ? '✕' : '☰'}
        </button>
      </div>

      {/* ── Menu mobile ── */}
      {mobileMenuOpen && (
        <div
          style={{
            position: 'fixed',
            top: 56,
            left: 0,
            right: 0,
            bottom: 0,
            background: theme.bg,
            zIndex: 49,
            padding: 24,
            animation: 'fadeIn 0.2s ease-out',
          }}
        >
          <nav style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setMobileMenuOpen(false)}
                style={{
                  padding: '14px 18px',
                  borderRadius: 12,
                  fontSize: 16,
                  fontWeight: 500,
                  textDecoration: 'none',
                  color:
                    pathname === item.path ? theme.accent : theme.textMuted,
                  background:
                    pathname === item.path
                      ? theme.accentGlow
                      : theme.surface,
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}

      {/* ── Media queries inline (via style tag) ── */}
      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .desktop-only { display: none !important; }
          .mobile-only { display: block !important; }
        }
        @media (min-width: 769px) {
          .mobile-only { display: none !important; }
        }
      `}</style>
    </header>
  );
}
