/**
 * Footer — Pied de page responsive
 */

import { Link } from 'react-router-dom';
import theme from '@/styles/theme';

export default function Footer() {
  return (
    <footer
      style={{
        marginTop: 'auto',
        borderTop: `1px solid ${theme.border}`,
        padding: '40px 24px 24px',
        background: theme.surface,
      }}
    >
      <div
        style={{
          maxWidth: 1100,
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: 32,
        }}
      >
        {/* Brand */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <span style={{ fontSize: 18 }}>⛨</span>
            <span style={{ fontFamily: theme.fontSerif, fontSize: 17 }}>ContractShield</span>
          </div>
          <p style={{ fontSize: 13, color: theme.textDim, lineHeight: 1.6 }}>
            Analyse IA de contrats.<br />
            Détection de clauses abusives.
          </p>
        </div>

        {/* Produit */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: theme.textMuted, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>
            Produit
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { to: '/analyze', label: 'Analyser un contrat' },
              { to: '/pricing', label: 'Tarifs' },
              { to: '#', label: 'API (bientôt)' },
            ].map((link) => (
              <Link
                key={link.label}
                to={link.to}
                style={{ fontSize: 14, color: theme.textDim, textDecoration: 'none' }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </div>

        {/* Legal */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: theme.textMuted, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>
            Légal
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {['CGU', 'Politique de confidentialité', 'Mentions légales'].map((label) => (
              <a
                key={label}
                href="#"
                style={{ fontSize: 14, color: theme.textDim, textDecoration: 'none' }}
              >
                {label}
              </a>
            ))}
          </div>
        </div>

        {/* Contact */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: theme.textMuted, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 1 }}>
            Contact
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <a href="mailto:contact@contractshield.io" style={{ fontSize: 14, color: theme.textDim, textDecoration: 'none' }}>
              contact@contractshield.io
            </a>
            <a href="#" style={{ fontSize: 14, color: theme.textDim, textDecoration: 'none' }}>
              Twitter / X
            </a>
            <a href="#" style={{ fontSize: 14, color: theme.textDim, textDecoration: 'none' }}>
              LinkedIn
            </a>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div
        style={{
          maxWidth: 1100,
          margin: '32px auto 0',
          paddingTop: 20,
          borderTop: `1px solid ${theme.border}`,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          flexWrap: 'wrap',
          gap: 8,
        }}
      >
        <span style={{ fontSize: 13, color: theme.textDim }}>
          © {new Date().getFullYear()} ContractShield. Tous droits réservés.
        </span>
        <span style={{ fontSize: 12, color: theme.textDim, fontFamily: theme.fontMono }}>
          v1.0.0-beta
        </span>
      </div>
    </footer>
  );
}
