/**
 * AnalyzingAnimation — Overlay animé pendant l'analyse
 * Affiche un scanner visuel + étapes d'analyse + barre de progression
 */

import theme from '@/styles/theme';

const ANALYSIS_STEPS = [
  'Extraction du texte...',
  'Identification des clauses...',
  'Analyse juridique IA...',
  'Détection des risques...',
  'Vérification des références légales...',
  'Génération du rapport...',
];

export default function AnalyzingAnimation({ progress = 0 }) {
  const stepIndex = Math.min(
    Math.floor((progress / 100) * ANALYSIS_STEPS.length),
    ANALYSIS_STEPS.length - 1
  );

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        background: 'rgba(11, 14, 20, 0.92)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        borderRadius: 20,
        backdropFilter: 'blur(4px)',
      }}
      role="alert"
      aria-live="polite"
      aria-label={`Analyse en cours : ${Math.round(progress)}%`}
    >
      {/* Ligne de scan animée */}
      <div
        style={{
          position: 'absolute',
          left: '10%',
          right: '10%',
          height: 2,
          background: `linear-gradient(90deg, transparent, ${theme.accent}, transparent)`,
          animation: 'scanLine 2s linear infinite',
          opacity: 0.7,
        }}
      />

      {/* Contenu centré */}
      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center' }}>
        {/* Icône animée */}
        <div
          style={{
            fontSize: 48,
            marginBottom: 20,
            animation: 'float 2s ease-in-out infinite',
          }}
        >
          🔍
        </div>

        {/* Titre */}
        <div
          style={{
            fontFamily: theme.fontSerif,
            fontSize: 22,
            marginBottom: 8,
            color: theme.text,
          }}
        >
          Analyse en cours...
        </div>

        {/* Étape courante */}
        <div
          style={{
            fontFamily: theme.fontMono,
            fontSize: 13,
            color: theme.accent,
            marginBottom: 24,
            minHeight: 20,
            transition: 'opacity 0.3s',
          }}
        >
          {ANALYSIS_STEPS[stepIndex]}
        </div>

        {/* Barre de progression */}
        <div
          style={{
            width: 260,
            height: 4,
            background: theme.border,
            borderRadius: 2,
            overflow: 'hidden',
            margin: '0 auto',
          }}
        >
          <div
            style={{
              width: `${Math.min(progress, 100)}%`,
              height: '100%',
              borderRadius: 2,
              background: `linear-gradient(90deg, ${theme.accent}, ${theme.accentDark})`,
              transition: 'width 0.3s ease-out',
              boxShadow: `0 0 12px ${theme.accent}60`,
            }}
          />
        </div>

        {/* Pourcentage */}
        <div
          style={{
            fontFamily: theme.fontMono,
            fontSize: 12,
            color: theme.textDim,
            marginTop: 10,
          }}
        >
          {Math.round(Math.min(progress, 100))}%
        </div>
      </div>
    </div>
  );
}
