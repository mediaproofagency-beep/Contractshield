/**
 * RiskBadge — Badge coloré indiquant le niveau de risque
 */

import { RISK_LEVELS } from '@/styles/theme';

export default function RiskBadge({ risk, size = 'md' }) {
  const level = RISK_LEVELS[risk];
  if (!level) return null;

  const sizes = {
    sm: { padding: '2px 8px', fontSize: '11px', gap: '4px' },
    md: { padding: '4px 12px', fontSize: '12px', gap: '6px' },
    lg: { padding: '6px 16px', fontSize: '13px', gap: '8px' },
  };

  const s = sizes[size] || sizes.md;

  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: s.gap,
        padding: s.padding,
        borderRadius: '20px',
        fontSize: s.fontSize,
        fontWeight: 600,
        background: level.bg,
        color: level.color,
        whiteSpace: 'nowrap',
      }}
    >
      {level.icon} {level.label}
    </span>
  );
}
