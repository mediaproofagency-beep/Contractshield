/**
 * LoadingSpinner — Spinner de chargement réutilisable
 */

export default function LoadingSpinner({ size = 24, color = 'var(--accent)' }) {
  return (
    <div
      style={{
        width: size,
        height: size,
        border: `2px solid var(--border)`,
        borderTopColor: color,
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
        flexShrink: 0,
      }}
      role="status"
      aria-label="Chargement..."
    />
  );
}
