/**
 * ScoreRing — Indicateur circulaire animé du score de risque
 */

import { useEffect, useState } from 'react';
import { getScoreColor } from '@/styles/theme';

export default function ScoreRing({ score, size = 120, strokeWidth = 8 }) {
  const [animatedOffset, setAnimatedOffset] = useState(null);
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const targetOffset = circumference - (score / 100) * circumference;
  const color = getScoreColor(score);

  // Animer le cercle à l'apparition
  useEffect(() => {
    const timer = setTimeout(() => setAnimatedOffset(targetOffset), 100);
    return () => clearTimeout(timer);
  }, [targetOffset]);

  return (
    <svg
      width={size}
      height={size}
      style={{ transform: 'rotate(-90deg)' }}
      role="img"
      aria-label={`Score de risque : ${score}/100`}
    >
      {/* Cercle de fond */}
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="var(--border)"
        strokeWidth={strokeWidth}
      />
      {/* Cercle de score (animé) */}
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeDasharray={circumference}
        strokeDashoffset={animatedOffset ?? circumference}
        strokeLinecap="round"
        style={{
          transition: 'stroke-dashoffset 1.8s cubic-bezier(0.4, 0, 0.2, 1)',
          filter: `drop-shadow(0 0 8px ${color}40)`,
        }}
      />
    </svg>
  );
}
