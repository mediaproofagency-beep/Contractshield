/**
 * UploadZone — Zone de drag & drop pour upload de contrats
 * Supporte PDF, DOCX, JPG, PNG
 * Validation du format et de la taille intégrée
 */

import { useState, useRef, useCallback } from 'react';
import theme from '@/styles/theme';
import { ACCEPTED_EXTENSIONS, formatFileSize, MAX_FILE_SIZE } from '@/utils/fileValidation';
import { validateFile } from '@/api/mockBackend';

export default function UploadZone({ onFileSelect, disabled = false }) {
  const [dragging, setDragging] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);

  const handleFile = useCallback(
    (file) => {
      setError(null);
      setSelectedFile(null);

      const validation = validateFile(file);
      if (!validation.valid) {
        setError(validation.error);
        return;
      }

      setSelectedFile(file);
      onFileSelect?.(file);
    },
    [onFileSelect]
  );

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault();
      setDragging(false);
      if (disabled) return;

      const file = e.dataTransfer?.files?.[0];
      if (file) handleFile(file);
    },
    [disabled, handleFile]
  );

  const handleDragOver = (e) => {
    e.preventDefault();
    if (!disabled) setDragging(true);
  };

  const handleClick = () => {
    if (!disabled) inputRef.current?.click();
  };

  const handleInputChange = (e) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    // Reset input pour permettre re-upload du même fichier
    e.target.value = '';
  };

  return (
    <div>
      {/* Zone de drop */}
      <div
        role="button"
        tabIndex={0}
        aria-label="Zone de dépôt de fichier. Cliquez ou glissez un fichier ici."
        onDragOver={handleDragOver}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={handleClick}
        onKeyDown={(e) => e.key === 'Enter' && handleClick()}
        style={{
          border: `2px dashed ${error ? theme.danger : dragging ? theme.accent : theme.border}`,
          borderRadius: 20,
          padding: selectedFile ? '36px 40px' : '56px 40px',
          textAlign: 'center',
          transition: 'all 0.3s ease',
          cursor: disabled ? 'not-allowed' : 'pointer',
          background: error
            ? theme.dangerGlow
            : dragging
              ? theme.accentGlow
              : 'transparent',
          opacity: disabled ? 0.5 : 1,
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.docx,.doc,.jpg,.jpeg,.png"
          onChange={handleInputChange}
          style={{ display: 'none' }}
          aria-hidden="true"
        />

        {/* Icône */}
        <div
          style={{
            fontSize: selectedFile ? 36 : 48,
            marginBottom: selectedFile ? 12 : 18,
            transition: 'all 0.3s',
          }}
        >
          {selectedFile ? '✅' : dragging ? '⬇️' : '📎'}
        </div>

        {/* Texte principal */}
        <div
          style={{
            fontFamily: theme.fontSerif,
            fontSize: selectedFile ? 18 : 22,
            marginBottom: 8,
            color: selectedFile ? theme.success : theme.text,
          }}
        >
          {selectedFile
            ? selectedFile.name
            : dragging
              ? 'Déposez votre fichier ici'
              : 'Glissez votre contrat ici'}
        </div>

        {/* Sous-texte */}
        {selectedFile ? (
          <p style={{ color: theme.textMuted, fontSize: 14, marginBottom: 12 }}>
            {formatFileSize(selectedFile.size)} · Prêt pour l'analyse
          </p>
        ) : (
          <p style={{ color: theme.textMuted, fontSize: 14, marginBottom: 18 }}>
            ou cliquez pour sélectionner un fichier
          </p>
        )}

        {/* Badges de format (seulement si pas de fichier sélectionné) */}
        {!selectedFile && (
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
            {ACCEPTED_EXTENSIONS.map((ext) => (
              <span
                key={ext}
                style={{
                  fontFamily: theme.fontMono,
                  padding: '4px 10px',
                  background: theme.surfaceAlt,
                  borderRadius: 6,
                  fontSize: 11,
                  color: theme.textDim,
                }}
              >
                {ext}
              </span>
            ))}
          </div>
        )}

        {/* Taille max */}
        {!selectedFile && (
          <p
            style={{
              fontSize: 12,
              color: theme.textDim,
              marginTop: 14,
              fontFamily: theme.fontMono,
            }}
          >
            Max {MAX_FILE_SIZE / (1024 * 1024)} Mo
          </p>
        )}
      </div>

      {/* Message d'erreur */}
      {error && (
        <div
          style={{
            marginTop: 12,
            padding: '10px 16px',
            borderRadius: 10,
            background: theme.dangerGlow,
            border: `1px solid ${theme.danger}30`,
            color: theme.danger,
            fontSize: 14,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            animation: 'fadeIn 0.3s ease-out',
          }}
        >
          <span>⚠️</span> {error}
        </div>
      )}
    </div>
  );
}
