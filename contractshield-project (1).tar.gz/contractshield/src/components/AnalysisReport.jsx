/**
 * AnalysisReport — Affiche le rapport complet d'analyse
 * Score, résumé, distribution des risques, clauses détaillées
 */

import { Link } from 'react-router-dom';
import ScoreRing from '@/components/common/ScoreRing';
import ClauseCard from '@/components/ClauseCard';
import { RISK_LEVELS, getScoreColor, getScoreLabel } from '@/styles/theme';
import theme from '@/styles/theme';

export default function AnalysisReport({ report, onNewAnalysis }) {
  if (!report) return null;

  const scoreColor = getScoreColor(report.score);
  const scoreLabel = getScoreLabel(report.score);

  return (
    <div
      style={{
        maxWidth: 1100,
        margin: '0 auto',
        padding: '40px 24px',
        animation: 'fadeIn 0.5s ease-out',
      }}
    >
      {/* ── Header du rapport ── */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'flex-start',
          marginBottom: 32,
          flexWrap: 'wrap',
          gap: 16,
        }}
      >
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8, flexWrap: 'wrap' }}>
            <span className="tag" style={{ background: theme.infoGlow, color: theme.info }}>
              {report.type}
            </span>
            <span style={{ fontFamily: theme.fontMono, fontSize: 12, color: theme.textDim }}>
              Analysé le{' '}
              {new Date().toLocaleDateString('fr-FR', {
                day: 'numeric',
                month: 'long',
                year: 'numeric',
              })}
            </span>
          </div>
          <h2 style={{ fontFamily: theme.fontSerif, fontSize: 28 }}>{report.title}</h2>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button className="btn-ghost" style={{ fontSize: 13 }}>
            📄 Export PDF
          </button>
          <button className="btn-ghost" style={{ fontSize: 13 }}>
            📧 Partager
          </button>
          <button className="btn-primary" onClick={onNewAnalysis} style={{ fontSize: 13 }}>
            + Nouvelle analyse
          </button>
        </div>
      </div>

      {/* ── Score + Résumé ── */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: '220px 1fr',
          gap: 20,
          marginBottom: 28,
        }}
        className="report-grid"
      >
        {/* Score ring */}
        <div
          className="glass"
          style={{
            borderRadius: 16,
            padding: 24,
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <div style={{ position: 'relative', display: 'inline-block' }}>
            <ScoreRing score={report.score} size={130} strokeWidth={10} />
            <div
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
              }}
            >
              <div style={{ fontFamily: theme.fontSerif, fontSize: 34, color: scoreColor }}>
                {report.score}
              </div>
              <div style={{ fontSize: 11, color: theme.textDim }}>/100</div>
            </div>
          </div>
          <div style={{ marginTop: 12, fontSize: 14, fontWeight: 600, color: scoreColor }}>
            {scoreLabel}
          </div>
        </div>

        {/* Résumé */}
        <div className="glass" style={{ borderRadius: 16, padding: 24 }}>
          <h3
            style={{
              fontSize: 13,
              fontWeight: 600,
              color: theme.textMuted,
              marginBottom: 10,
              textTransform: 'uppercase',
              letterSpacing: 1,
            }}
          >
            Résumé de l'analyse
          </h3>
          <p style={{ fontSize: 15, lineHeight: 1.7, marginBottom: 20 }}>
            {report.summary}
          </p>

          {/* Stats rapides */}
          <div
            style={{
              display: 'flex',
              gap: 24,
              flexWrap: 'wrap',
            }}
          >
            {[
              { label: 'Clauses analysées', value: report.stats.totalClauses, color: theme.info },
              { label: 'Alertes', value: report.stats.riskyCount, color: theme.danger },
              { label: 'Pages', value: report.stats.pagesAnalyzed, color: theme.textMuted },
              { label: 'Temps', value: `${report.stats.timeSeconds}s`, color: theme.accent },
            ].map((s, i) => (
              <div key={i}>
                <div style={{ fontFamily: theme.fontMono, fontSize: 20, fontWeight: 700, color: s.color }}>
                  {s.value}
                </div>
                <div style={{ fontSize: 12, color: theme.textDim }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Distribution des risques ── */}
      <div className="glass" style={{ borderRadius: 16, padding: 20, marginBottom: 28 }}>
        <h3
          style={{
            fontSize: 13,
            fontWeight: 600,
            color: theme.textMuted,
            marginBottom: 14,
            textTransform: 'uppercase',
            letterSpacing: 1,
          }}
        >
          Distribution des risques
        </h3>

        {/* Barre visuelle */}
        <div
          style={{
            display: 'flex',
            gap: 3,
            height: 8,
            borderRadius: 4,
            overflow: 'hidden',
          }}
        >
          {Object.entries(RISK_LEVELS).map(([key, val]) => {
            const count = report.clauses.filter((c) => c.risk === key).length;
            if (!count) return null;
            return (
              <div
                key={key}
                style={{ flex: count, background: val.color, borderRadius: 4 }}
              />
            );
          })}
        </div>

        {/* Légende */}
        <div style={{ display: 'flex', gap: 20, marginTop: 12, flexWrap: 'wrap' }}>
          {Object.entries(RISK_LEVELS).map(([key, val]) => {
            const count = report.clauses.filter((c) => c.risk === key).length;
            if (!count) return null;
            return (
              <div
                key={key}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                  fontSize: 13,
                  color: theme.textMuted,
                }}
              >
                <div
                  style={{
                    width: 8,
                    height: 8,
                    borderRadius: 2,
                    background: val.color,
                  }}
                />
                {val.label} : {count}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Liste des clauses ── */}
      <h3
        style={{
          fontFamily: theme.fontSerif,
          fontSize: 22,
          marginBottom: 18,
        }}
      >
        Clauses détectées ({report.clauses.length})
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {report.clauses.map((clause, i) => (
          <ClauseCard key={clause.id} clause={clause} index={i} />
        ))}
      </div>

      {/* ── CTA upgrade ── */}
      <div
        style={{
          textAlign: 'center',
          marginTop: 40,
          padding: 32,
          background: theme.surface,
          borderRadius: 16,
          border: `1px solid ${theme.border}`,
        }}
      >
        <div style={{ fontFamily: theme.fontSerif, fontSize: 20, marginBottom: 8 }}>
          Besoin d'aller plus loin ?
        </div>
        <p style={{ color: theme.textMuted, marginBottom: 20, fontSize: 14 }}>
          Passez au plan Professional pour des suggestions de reformulation complètes
        </p>
        <Link to="/pricing">
          <button className="btn-primary">Voir les offres →</button>
        </Link>
      </div>

      {/* ── Responsive styles ── */}
      <style>{`
        @media (max-width: 768px) {
          .report-grid {
            grid-template-columns: 1fr !important;
          }
        }
      `}</style>
    </div>
  );
}
