/**
 * ClauseCard — Carte dépliable d'une clause détectée
 * Affiche le texte original, le problème, la suggestion,
 * et la référence juridique.
 */

import { useState } from 'react';
import RiskBadge from '@/components/common/RiskBadge';
import { RISK_LEVELS } from '@/styles/theme';
import theme from '@/styles/theme';

export default function ClauseCard({ clause, index = 0 }) {
  const [expanded, setExpanded] = useState(false);
  const riskLevel = RISK_LEVELS[clause.risk];

  return (
    <div
      onClick={() => setExpanded(!expanded)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && setExpanded(!expanded)}
      aria-expanded={expanded}
      style={{
        border: `1px solid ${theme.border}`,
        borderLeft: `3px solid ${riskLevel?.color || theme.border}`,
        borderRadius: 14,
        padding: '20px 24px',
        background: theme.surface,
        transition: 'all 0.3s ease',
        cursor: 'pointer',
        animation: `fadeIn 0.5s ease-out ${index * 0.1}s both`,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = theme.borderActive;
        e.currentTarget.style.transform = 'translateY(-2px)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = theme.border;
        e.currentTarget.style.borderLeftColor = riskLevel?.color || theme.border;
        e.currentTarget.style.transform = 'translateY(0)';
      }}
    >
      {/* ── En-tête ── */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: expanded ? 16 : 0,
          flexWrap: 'wrap',
          gap: 10,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <RiskBadge risk={clause.risk} />
          <span style={{ fontWeight: 600, fontSize: 15 }}>{clause.title}</span>
          <span
            style={{
              fontFamily: theme.fontMono,
              fontSize: 12,
              color: theme.textDim,
            }}
          >
            {clause.article}
          </span>
        </div>
        <span
          style={{
            color: theme.textDim,
            fontSize: 18,
            transition: 'transform 0.3s ease',
            transform: expanded ? 'rotate(180deg)' : 'rotate(0)',
            flexShrink: 0,
          }}
        >
          ▾
        </span>
      </div>

      {/* ── Contenu déplié ── */}
      {expanded && (
        <div style={{ animation: 'fadeIn 0.3s ease-out' }}>
          {/* Texte original */}
          <div
            style={{
              background: theme.surfaceAlt,
              borderRadius: 10,
              padding: 16,
              marginBottom: 14,
              borderLeft: `3px solid ${theme.textDim}`,
            }}
          >
            <div
              style={{
                fontFamily: theme.fontMono,
                fontSize: 11,
                color: theme.textDim,
                marginBottom: 6,
                textTransform: 'uppercase',
                letterSpacing: 0.5,
              }}
            >
              Texte original
            </div>
            <p
              style={{
                fontSize: 14,
                lineHeight: 1.6,
                color: theme.textMuted,
                fontStyle: 'italic',
              }}
            >
              « {clause.original} »
            </p>
          </div>

          {/* Problème identifié */}
          <div
            style={{
              background: riskLevel?.bg || theme.dangerGlow,
              borderRadius: 10,
              padding: 16,
              marginBottom: 14,
              borderLeft: `3px solid ${riskLevel?.color || theme.danger}`,
            }}
          >
            <div
              style={{
                fontFamily: theme.fontMono,
                fontSize: 11,
                color: riskLevel?.color || theme.danger,
                marginBottom: 6,
                textTransform: 'uppercase',
                letterSpacing: 0.5,
              }}
            >
              ⚠️ Problème identifié
            </div>
            <p style={{ fontSize: 14, lineHeight: 1.6, color: theme.text }}>
              {clause.problem}
            </p>
          </div>

          {/* Suggestion */}
          <div
            style={{
              background: theme.successGlow,
              borderRadius: 10,
              padding: 16,
              marginBottom: 12,
              borderLeft: `3px solid ${theme.success}`,
            }}
          >
            <div
              style={{
                fontFamily: theme.fontMono,
                fontSize: 11,
                color: theme.success,
                marginBottom: 6,
                textTransform: 'uppercase',
                letterSpacing: 0.5,
              }}
            >
              💡 Suggestion
            </div>
            <p style={{ fontSize: 14, lineHeight: 1.6, color: theme.text }}>
              {clause.suggestion}
            </p>
          </div>

          {/* Référence juridique */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              marginTop: 8,
            }}
          >
            <span style={{ fontSize: 12 }}>📚</span>
            <span
              style={{
                fontFamily: theme.fontMono,
                fontSize: 12,
                color: theme.info,
              }}
            >
              {clause.legalRef}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
