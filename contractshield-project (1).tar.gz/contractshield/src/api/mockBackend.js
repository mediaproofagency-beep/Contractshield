/**
 * ──────────────────────────────────────────────
 * ContractShield — Backend Simulé (Mock API)
 * ──────────────────────────────────────────────
 * Ce module simule le backend de l'application.
 * À remplacer par de vrais appels API en production.
 *
 * Fonctionnalités :
 *  - analyzeContract(file)   → Analyse simulée d'un contrat
 *  - extractText(file)       → Extraction de texte simulée
 *  - generateReport(text)    → Génération de rapport IA simulée
 */

import { CLAUSE_POOL } from '@/data/mockAnalyses';

// ─── Configuration ──────────────────────────
const CONFIG = {
  /** Délai d'analyse simulé en ms */
  analysisDelay: 3000,
  /** Taille max de fichier en octets (20 Mo) */
  maxFileSize: 20 * 1024 * 1024,
  /** Formats de fichier acceptés */
  acceptedFormats: [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/msword',
    'image/jpeg',
    'image/png',
    'image/webp',
  ],
  /** Extensions acceptées */
  acceptedExtensions: ['.pdf', '.docx', '.doc', '.jpg', '.jpeg', '.png', '.webp'],
};

// ─── Validation de fichier ──────────────────

/**
 * Valide un fichier uploadé
 * @param {File} file - Le fichier à valider
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateFile(file) {
  if (!file) {
    return { valid: false, error: 'Aucun fichier fourni.' };
  }

  // Vérifier la taille
  if (file.size > CONFIG.maxFileSize) {
    const maxMb = CONFIG.maxFileSize / (1024 * 1024);
    const fileMb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      valid: false,
      error: `Fichier trop volumineux (${fileMb} Mo). Maximum : ${maxMb} Mo.`,
    };
  }

  // Vérifier le format via MIME type
  if (file.type && !CONFIG.acceptedFormats.includes(file.type)) {
    return {
      valid: false,
      error: `Format non supporté : ${file.type}. Formats acceptés : PDF, DOCX, JPG, PNG.`,
    };
  }

  // Vérifier via extension si MIME type absent
  const ext = '.' + file.name.split('.').pop().toLowerCase();
  if (!CONFIG.acceptedExtensions.includes(ext)) {
    return {
      valid: false,
      error: `Extension non supportée : ${ext}. Extensions acceptées : ${CONFIG.acceptedExtensions.join(', ')}.`,
    };
  }

  // Vérifier que le fichier n'est pas vide
  if (file.size === 0) {
    return { valid: false, error: 'Le fichier est vide ou corrompu.' };
  }

  return { valid: true };
}

// ─── Détection du type de contrat ───────────

/**
 * Détecte le type de contrat à partir du nom de fichier
 * @param {string} filename
 * @returns {'employment' | 'rental' | 'commercial'}
 */
function detectContractType(filename) {
  const lower = filename.toLowerCase();

  if (
    lower.includes('travail') ||
    lower.includes('cdi') ||
    lower.includes('cdd') ||
    lower.includes('emploi') ||
    lower.includes('embauche') ||
    lower.includes('salari')
  ) {
    return 'employment';
  }

  if (
    lower.includes('bail') ||
    lower.includes('location') ||
    lower.includes('loyer') ||
    lower.includes('habitation') ||
    lower.includes('logement')
  ) {
    return 'rental';
  }

  // Par défaut : commercial
  return 'commercial';
}

// ─── Générateur de clauses aléatoires ───────

/**
 * Sélectionne des clauses aléatoires depuis le pool
 * @param {string} type - Type de contrat
 * @param {number} count - Nombre de clauses à sélectionner
 * @returns {Array} Clauses sélectionnées avec IDs
 */
function pickRandomClauses(type, count) {
  const pool = CLAUSE_POOL[type] || CLAUSE_POOL.commercial;

  // Mélanger le pool (Fisher-Yates shuffle)
  const shuffled = [...pool].sort(() => Math.random() - 0.5);

  // Sélectionner le nombre demandé
  const selected = shuffled.slice(0, Math.min(count, shuffled.length));

  // Assigner des IDs
  return selected.map((clause, index) => ({
    ...clause,
    id: index + 1,
  }));
}

// ─── Extraction de texte simulée ────────────

/**
 * Simule l'extraction de texte d'un fichier
 * En production, utiliserait pdf.js, Tesseract OCR, ou une API
 *
 * @param {File} file
 * @returns {Promise<string>}
 */
export async function extractText(file) {
  // Simule un délai d'extraction
  await new Promise((resolve) => setTimeout(resolve, 800));

  // En mode démo, retourne un texte placeholder
  return `[Texte extrait de ${file.name}] — ${file.size} octets analysés. 
  Contenu simulé pour la démonstration. En production, le texte réel 
  serait extrait via pdf.js pour les PDF ou mammoth.js pour les DOCX.`;
}

// ─── Fonction principale d'analyse ──────────

/**
 * Analyse un contrat et retourne un rapport structuré.
 *
 * @param {File} file - Le fichier du contrat à analyser
 * @param {Object} options
 * @param {function} options.onProgress - Callback de progression (0-100)
 * @returns {Promise<Object>} Rapport d'analyse structuré
 *
 * @throws {Error} Si le fichier est invalide
 *
 * @example
 * const report = await analyzeContract(file, {
 *   onProgress: (p) => setProgress(p)
 * });
 * console.log(report.score); // 34
 * console.log(report.clauses); // [{...}, ...]
 */
export async function analyzeContract(file, options = {}) {
  const { onProgress = () => {} } = options;

  // ── Étape 1 : Validation ──
  onProgress(0);
  const validation = validateFile(file);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  // ── Étape 2 : Extraction du texte (simulée) ──
  onProgress(10);
  await new Promise((r) => setTimeout(r, 500));
  onProgress(20);

  const extractedText = await extractText(file);
  onProgress(35);

  // ── Étape 3 : Détection du type de contrat ──
  const contractType = detectContractType(file.name);
  onProgress(45);

  // ── Étape 4 : Analyse IA (simulée) ──
  await new Promise((r) => setTimeout(r, 600));
  onProgress(60);

  // Sélectionner des clauses aléatoires
  const clauseCount = Math.floor(Math.random() * 3) + 3; // 3-5 clauses
  const clauses = pickRandomClauses(contractType, clauseCount);
  onProgress(75);

  // ── Étape 5 : Calcul du score ──
  await new Promise((r) => setTimeout(r, 500));
  onProgress(85);

  // Score basé sur la sévérité des clauses détectées
  const riskWeights = { critical: 20, high: 12, medium: 6, low: 2 };
  const totalRiskPoints = clauses.reduce(
    (sum, c) => sum + (riskWeights[c.risk] || 0),
    0
  );
  // Score inversé : plus de risque = score plus bas
  const baseScore = Math.max(15, Math.min(85, 100 - totalRiskPoints * 1.5));
  // Ajouter un peu d'aléatoire
  const score = Math.floor(baseScore + (Math.random() * 10 - 5));

  onProgress(95);

  // ── Étape 6 : Génération du rapport ──
  await new Promise((r) => setTimeout(r, 400));

  const typeLabels = {
    employment: 'Emploi',
    rental: 'Immobilier',
    commercial: 'Commercial',
  };

  const typeTitles = {
    employment: 'Contrat de Travail',
    rental: "Bail d'Habitation",
    commercial: 'Contrat Commercial',
  };

  const riskyCount = clauses.filter(
    (c) => c.risk === 'critical' || c.risk === 'high'
  ).length;

  const report = {
    title: `${typeTitles[contractType]} — ${file.name.replace(/\.[^.]+$/, '')}`,
    type: typeLabels[contractType],
    contractType,
    score: Math.max(10, Math.min(95, score)),
    summary: generateSummary(score, riskyCount, clauses.length),
    clauses,
    stats: {
      totalClauses: clauses.length + Math.floor(Math.random() * 10) + 5,
      riskyCount,
      pagesAnalyzed: Math.floor(file.size / 3000) + Math.floor(Math.random() * 5) + 3,
      timeSeconds: ((Date.now() % 1000) / 100 + 2).toFixed(1),
    },
    metadata: {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      analyzedAt: new Date().toISOString(),
      version: '1.0.0-beta',
    },
  };

  onProgress(100);

  return report;
}

/**
 * Génère un résumé textuel basé sur le score
 */
function generateSummary(score, riskyCount, totalDetected) {
  if (score < 35) {
    return `Ce contrat contient ${riskyCount} clauses à risque élevé sur ${totalDetected} détectées. Plusieurs dispositions sont potentiellement abusives ou non conformes à la législation en vigueur. Une renégociation approfondie est fortement recommandée avant toute signature.`;
  }
  if (score < 60) {
    return `Le contrat présente un niveau de risque modéré avec ${riskyCount} clause(s) problématique(s) sur ${totalDetected} analysée(s). Certains points méritent une attention particulière et une discussion avec la partie adverse.`;
  }
  if (score < 80) {
    return `Le contrat est globalement équilibré. ${totalDetected} clauses ont été analysées et ${riskyCount} point(s) d'attention mineur(s) ont été identifié(s). Quelques ajustements recommandés pour une protection optimale.`;
  }
  return `Excellent contrat. Sur ${totalDetected} clauses analysées, le document respecte les standards légaux en vigueur. Les dispositions sont équilibrées et conformes à la jurisprudence actuelle.`;
}

// ─── Gestion de l'historique local ──────────

const HISTORY_KEY = 'contractshield_history';

/**
 * Sauvegarde une analyse dans l'historique local
 * @param {Object} report - Le rapport d'analyse
 */
export function saveToHistory(report) {
  try {
    const history = getHistory();
    const entry = {
      id: Date.now(),
      title: report.title,
      type: report.type,
      score: report.score,
      riskyCount: report.stats.riskyCount,
      date: new Date().toLocaleDateString('fr-FR', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }),
      analyzedAt: report.metadata.analyzedAt,
    };
    history.unshift(entry);
    // Garder les 50 dernières analyses
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 50)));
  } catch (e) {
    console.warn('Impossible de sauvegarder dans l\'historique:', e);
  }
}

/**
 * Récupère l'historique des analyses
 * @returns {Array}
 */
export function getHistory() {
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/**
 * Supprime une entrée de l'historique
 * @param {number} id
 */
export function deleteFromHistory(id) {
  const history = getHistory().filter((h) => h.id !== id);
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}

export default {
  analyzeContract,
  validateFile,
  extractText,
  saveToHistory,
  getHistory,
  deleteFromHistory,
};
