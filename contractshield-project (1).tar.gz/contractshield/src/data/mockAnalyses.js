/**
 * ─────────────────────────────────────────
 * ContractShield — Données d'analyse mock
 * ─────────────────────────────────────────
 * Exemples réalistes de rapports d'analyse
 * utilisés pour la démo et les tests.
 */

/**
 * Pool de clauses par catégorie
 * Utilisé pour générer des analyses aléatoires
 */
export const CLAUSE_POOL = {
  employment: [
    {
      title: 'Clause de non-concurrence excessive',
      risk: 'critical',
      article: 'Article 12.3',
      original:
        "Le salarié s'engage à ne pas exercer d'activité concurrente pendant une durée de 36 mois sur l'ensemble du territoire national, sans contrepartie financière.",
      problem:
        'Durée de 36 mois sans contrepartie financière. La jurisprudence limite généralement à 24 mois avec indemnité compensatrice obligatoire (min. 33% du salaire).',
      suggestion:
        'Réduire à 12-18 mois, limiter géographiquement, et exiger une contrepartie financière d\'au moins 40% du salaire mensuel.',
      legalRef: 'Cass. Soc. 10 juillet 2002 / Art. L1121-1 Code du Travail',
    },
    {
      title: 'Clause de mobilité sans limite',
      risk: 'high',
      article: 'Article 5.1',
      original:
        "L'employeur se réserve le droit de muter le salarié dans tout établissement du groupe, en France ou à l'étranger, sans délai de prévenance.",
      problem:
        "Absence de zone géographique définie et de délai de prévenance. Cette clause pourrait être jugée abusive par les prud'hommes.",
      suggestion:
        'Définir précisément la zone géographique (ex: Île-de-France) et imposer un délai de prévenance minimum de 2 mois.',
      legalRef: 'Cass. Soc. 12 janvier 2016, n°14-23.290',
    },
    {
      title: 'Propriété intellectuelle élargie',
      risk: 'high',
      article: 'Article 8.2',
      original:
        "Toute création réalisée par le salarié, même en dehors des heures de travail, est la propriété exclusive de l'employeur.",
      problem:
        "La cession des droits sur les créations personnelles hors temps de travail dépasse le cadre légal de l'Art. L611-7 du CPI.",
      suggestion:
        'Limiter la cession aux créations réalisées dans le cadre des missions professionnelles uniquement.',
      legalRef: 'Art. L611-7 Code de la Propriété Intellectuelle',
    },
    {
      title: "Période d'essai à la limite légale",
      risk: 'medium',
      article: 'Article 3.1',
      original:
        "La période d'essai est fixée à 4 mois, renouvelable une fois pour une durée identique.",
      problem:
        "Bien que légal pour un cadre, le renouvellement doit être expressément accepté par le salarié. Vérifiez la convention collective applicable.",
      suggestion:
        'Clarifier les conditions de renouvellement et vérifier la convention collective applicable qui peut prévoir des durées inférieures.',
      legalRef: 'Art. L1221-19 à L1221-26 Code du Travail',
    },
    {
      title: 'Clause de confidentialité raisonnable',
      risk: 'low',
      article: 'Article 11.1',
      original:
        "Le salarié s'engage à ne divulguer aucune information confidentielle pendant et après la durée du contrat.",
      problem:
        'Clause standard et proportionnée. La durée post-contractuelle pourrait être précisée pour plus de clarté.',
      suggestion:
        'Aucune modification majeure nécessaire. Préciser la durée post-contractuelle (2-3 ans recommandés).',
      legalRef: 'Art. 1104 Code Civil',
    },
    {
      title: 'Clause de dédit-formation abusive',
      risk: 'critical',
      article: 'Article 9.4',
      original:
        "En cas de démission dans les 5 ans suivant une formation, le salarié remboursera l'intégralité des frais, y compris le salaire perçu pendant la formation.",
      problem:
        'Durée de 5 ans excessive. Le remboursement du salaire en plus des frais de formation rend la clause disproportionnée.',
      suggestion:
        'Limiter à 2-3 ans maximum, ne rembourser que les frais pédagogiques réels, avec dégressivité annuelle.',
      legalRef: 'Cass. Soc. 21 mai 2002, n°00-42.909',
    },
    {
      title: 'Horaires flexibles encadrés',
      risk: 'low',
      article: 'Article 4.2',
      original:
        "Le salarié bénéficie d'horaires flexibles avec plages fixes de 10h à 16h et une amplitude maximale de 7h30 à 19h.",
      problem:
        'Clause bien rédigée et conforme aux dispositions légales sur le temps de travail.',
      suggestion: 'Aucune modification nécessaire. Clause conforme.',
      legalRef: 'Art. L3121-44 Code du Travail',
    },
  ],
  rental: [
    {
      title: 'Clause résolutoire accélérée',
      risk: 'high',
      article: 'Article 9',
      original:
        "En cas de non-paiement du loyer, le bail sera résilié de plein droit 15 jours après mise en demeure restée infructueuse.",
      problem:
        "Le délai de 15 jours est inférieur au minimum légal de 2 mois prévu par la loi ALUR pour les baux d'habitation.",
      suggestion:
        'Exiger la mise en conformité avec le délai légal de 2 mois minimum avant toute clause résolutoire.',
      legalRef: 'Loi n°89-462 du 6 juillet 1989, Art. 24',
    },
    {
      title: 'Répartition des charges opaque',
      risk: 'medium',
      article: 'Article 5.2',
      original:
        'Les charges sont fixées forfaitairement à 200€/mois sans régularisation annuelle.',
      problem:
        "Un forfait de charges sans régularisation peut être désavantageux. La loi prévoit une régularisation annuelle obligatoire pour les baux d'habitation.",
      suggestion:
        'Demander une provision sur charges avec régularisation annuelle basée sur les dépenses réelles et justificatifs.',
      legalRef: 'Loi ALUR, Art. 23 de la loi du 6 juillet 1989',
    },
    {
      title: "État des lieux conforme",
      risk: 'low',
      article: 'Article 3',
      original:
        "Un état des lieux contradictoire sera établi à l'entrée et à la sortie du logement, conformément aux dispositions légales.",
      problem: 'Clause conforme à la législation en vigueur.',
      suggestion: 'Aucune modification nécessaire.',
      legalRef: 'Art. 3-2 Loi du 6 juillet 1989',
    },
    {
      title: 'Travaux à charge du locataire',
      risk: 'critical',
      article: 'Article 7.3',
      original:
        "Le locataire prend en charge l'ensemble des travaux de réparation, y compris les grosses réparations et la vétusté.",
      problem:
        "Les grosses réparations (Art. 606 Code Civil) incombent au propriétaire. Faire supporter la vétusté au locataire est illégal depuis la loi ALUR.",
      suggestion:
        "Supprimer la mention des grosses réparations et de la vétusté. Appliquer la grille de vétusté légale.",
      legalRef: 'Art. 606 Code Civil / Décret n°2016-382 du 30 mars 2016',
    },
    {
      title: 'Interdiction d\'animaux',
      risk: 'medium',
      article: 'Article 8.1',
      original:
        "Le locataire s'interdit formellement de détenir tout animal dans les lieux loués.",
      problem:
        "Une interdiction totale d'animaux est réputée non écrite (loi du 9 juillet 1970), sauf pour les animaux dangereux de 1ère catégorie.",
      suggestion:
        "Supprimer cette clause. Le bailleur ne peut interdire que les animaux dangereux de catégorie 1.",
      legalRef: 'Loi n°70-598 du 9 juillet 1970, Art. 10-I',
    },
  ],
  commercial: [
    {
      title: 'Clause de responsabilité limitée',
      risk: 'critical',
      article: 'Article 14.1',
      original:
        "La responsabilité du prestataire est limitée à 10% du montant total du contrat, tous dommages confondus.",
      problem:
        "Limitation à 10% potentiellement abusive entre professionnels. Aucune exclusion prévue pour faute lourde ou dol.",
      suggestion:
        "Porter le plafond à 100% minimum du contrat. Exclure la limitation pour faute lourde, dol et dommages corporels.",
      legalRef: 'Art. L442-1 Code de Commerce / Art. 1231-3 Code Civil',
    },
    {
      title: 'Clause de paiement tardif',
      risk: 'high',
      article: 'Article 6.2',
      original:
        "Le paiement des factures est dû à 90 jours fin de mois après émission.",
      problem:
        "Le délai de 90 jours dépasse le maximum légal de 60 jours (ou 45 jours fin de mois) entre professionnels.",
      suggestion:
        "Ramener le délai à 30 jours (recommandé) ou 60 jours maximum conformément à la loi LME.",
      legalRef: 'Art. L441-10 Code de Commerce (Loi LME)',
    },
    {
      title: 'Clause de résiliation équilibrée',
      risk: 'low',
      article: 'Article 12.1',
      original:
        "Chaque partie peut résilier le contrat avec un préavis de 3 mois par lettre recommandée avec AR.",
      problem: 'Clause équilibrée avec un préavis raisonnable identique pour les deux parties.',
      suggestion: 'Aucune modification nécessaire.',
      legalRef: 'Art. 1193 Code Civil',
    },
  ],
};

/**
 * Analyses complètes pré-construites pour la démo
 */
export const MOCK_ANALYSES = {
  employment: {
    title: 'Contrat de Travail — CDI',
    type: 'Emploi',
    score: 34,
    summary:
      "Ce contrat contient plusieurs clauses potentiellement abusives qui limitent significativement vos droits. Une renégociation est fortement recommandée avant signature.",
    clauses: CLAUSE_POOL.employment.slice(0, 5).map((c, i) => ({ ...c, id: i + 1 })),
    stats: { totalClauses: 18, riskyCount: 5, pagesAnalyzed: 12, timeSeconds: 4.2 },
  },
  rental: {
    title: "Bail d'Habitation — Location",
    type: 'Immobilier',
    score: 58,
    summary:
      "Le bail présente quelques clauses déséquilibrées mais reste globalement dans les normes. Attention particulière sur les charges et la clause résolutoire.",
    clauses: CLAUSE_POOL.rental.map((c, i) => ({ ...c, id: i + 1 })),
    stats: { totalClauses: 14, riskyCount: 3, pagesAnalyzed: 8, timeSeconds: 3.1 },
  },
  commercial: {
    title: 'Contrat de Prestation — CGV',
    type: 'Commercial',
    score: 52,
    summary:
      "Les conditions générales présentent des clauses limitant fortement vos recours. La limitation de responsabilité et les délais de paiement nécessitent une renégociation.",
    clauses: CLAUSE_POOL.commercial.map((c, i) => ({ ...c, id: i + 1 })),
    stats: { totalClauses: 22, riskyCount: 4, pagesAnalyzed: 16, timeSeconds: 5.8 },
  },
};

export default MOCK_ANALYSES;
