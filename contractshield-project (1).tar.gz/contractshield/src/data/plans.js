/**
 * ─────────────────────────────────────────
 * ContractShield — Plans d'abonnement
 * ─────────────────────────────────────────
 */

export const PLANS = [
  {
    id: 'starter',
    name: 'Starter',
    price: 29,
    currency: '€',
    period: '/mois',
    yearlyPrice: 24,
    description: 'Pour les particuliers',
    analysesPerMonth: 3,
    features: [
      '3 analyses / mois',
      'Détection clauses abusives',
      'Score de risque global',
      'Export PDF du rapport',
    ],
    cta: 'Essai gratuit 7 jours',
    popular: false,
    stripePriceId: import.meta.env.VITE_STRIPE_PRICE_STARTER || 'price_starter_mock',
  },
  {
    id: 'professional',
    name: 'Professional',
    price: 89,
    currency: '€',
    period: '/mois',
    yearlyPrice: 74,
    description: 'Pour les indépendants & PME',
    analysesPerMonth: 25,
    features: [
      '25 analyses / mois',
      'Tout Starter +',
      'Suggestions de reformulation IA',
      'Références juridiques détaillées',
      'Comparaison de versions',
      'Support prioritaire',
    ],
    cta: 'Commencer maintenant',
    popular: true,
    stripePriceId: import.meta.env.VITE_STRIPE_PRICE_PRO || 'price_pro_mock',
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 299,
    currency: '€',
    period: '/mois',
    yearlyPrice: 249,
    description: 'Pour les cabinets & grandes entreprises',
    analysesPerMonth: Infinity,
    features: [
      'Analyses illimitées',
      'Tout Professional +',
      'API d\'intégration REST',
      'Modèles IA personnalisés',
      'Multi-utilisateurs (jusqu\'à 50)',
      'SLA 99.9% & support dédié',
      'Formation équipe incluse',
    ],
    cta: 'Contacter l\'équipe',
    popular: false,
    stripePriceId: import.meta.env.VITE_STRIPE_PRICE_ENTERPRISE || 'price_enterprise_mock',
  },
];

export default PLANS;
