/**
 * ─────────────────────────────────────────
 * ContractShield — useAnalysis Hook
 * ─────────────────────────────────────────
 * Gère le flux complet d'analyse de contrat :
 * upload → validation → analyse → résultats
 */

import { useState, useCallback } from 'react';
import { analyzeContract, saveToHistory } from '@/api/mockBackend';

/**
 * @typedef {'idle' | 'validating' | 'analyzing' | 'complete' | 'error'} AnalysisStatus
 */

/**
 * Hook personnalisé pour l'analyse de contrats
 *
 * @returns {{
 *   status: AnalysisStatus,
 *   progress: number,
 *   report: Object|null,
 *   error: string|null,
 *   startAnalysis: (file: File) => Promise<void>,
 *   reset: () => void,
 * }}
 */
export function useAnalysis() {
  const [status, setStatus] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);

  /**
   * Démarre l'analyse d'un fichier
   */
  const startAnalysis = useCallback(async (file) => {
    try {
      setStatus('validating');
      setProgress(0);
      setError(null);
      setReport(null);

      // Petite pause pour le feedback visuel
      await new Promise((r) => setTimeout(r, 200));

      setStatus('analyzing');

      const result = await analyzeContract(file, {
        onProgress: (p) => setProgress(Math.min(p, 100)),
      });

      // Sauvegarder dans l'historique
      saveToHistory(result);

      setReport(result);
      setStatus('complete');
    } catch (err) {
      setError(err.message || "Une erreur est survenue lors de l'analyse.");
      setStatus('error');
    }
  }, []);

  /**
   * Réinitialise l'état pour une nouvelle analyse
   */
  const reset = useCallback(() => {
    setStatus('idle');
    setProgress(0);
    setReport(null);
    setError(null);
  }, []);

  return {
    status,
    progress,
    report,
    error,
    startAnalysis,
    reset,
    isAnalyzing: status === 'analyzing' || status === 'validating',
    isComplete: status === 'complete',
    isError: status === 'error',
  };
}

export default useAnalysis;
