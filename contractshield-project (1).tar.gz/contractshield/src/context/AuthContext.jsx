/**
 * ─────────────────────────────────────────
 * ContractShield — Auth Context
 * ─────────────────────────────────────────
 * Gestion de l'authentification simulée.
 * Utilise localStorage en mode développement.
 *
 * En production, remplacer par Firebase Auth
 * ou votre provider d'authentification.
 */

import { createContext, useContext, useState, useEffect, useCallback } from 'react';

const AuthContext = createContext(null);

const AUTH_KEY = 'contractshield_auth';
const USERS_KEY = 'contractshield_users';

/**
 * Provider d'authentification
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // ── Charger l'utilisateur au démarrage ──
  useEffect(() => {
    try {
      const saved = localStorage.getItem(AUTH_KEY);
      if (saved) {
        setUser(JSON.parse(saved));
      }
    } catch (e) {
      console.warn('Erreur chargement auth:', e);
      localStorage.removeItem(AUTH_KEY);
    }
    setLoading(false);
  }, []);

  // ── Inscription ──
  const signup = useCallback(async (email, password, name) => {
    // Simule un délai réseau
    await new Promise((r) => setTimeout(r, 800));

    // Vérifier si l'email existe déjà
    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
    if (users[email]) {
      throw new Error('Un compte existe déjà avec cet email.');
    }

    // Créer l'utilisateur
    const newUser = {
      id: `user_${Date.now()}`,
      email,
      name: name || email.split('@')[0],
      plan: 'free',
      analysesRemaining: 1, // 1 analyse gratuite
      createdAt: new Date().toISOString(),
    };

    // Sauvegarder (mock DB)
    users[email] = { ...newUser, password }; // En prod, JAMAIS stocker le mot de passe en clair !
    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    // Connecter
    const { password: _, ...safeUser } = users[email];
    localStorage.setItem(AUTH_KEY, JSON.stringify(safeUser));
    setUser(safeUser);

    return safeUser;
  }, []);

  // ── Connexion ──
  const login = useCallback(async (email, password) => {
    await new Promise((r) => setTimeout(r, 600));

    const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
    const found = users[email];

    if (!found || found.password !== password) {
      throw new Error('Email ou mot de passe incorrect.');
    }

    const { password: _, ...safeUser } = found;
    localStorage.setItem(AUTH_KEY, JSON.stringify(safeUser));
    setUser(safeUser);

    return safeUser;
  }, []);

  // ── Déconnexion ──
  const logout = useCallback(() => {
    localStorage.removeItem(AUTH_KEY);
    setUser(null);
  }, []);

  // ── Mettre à jour le profil ──
  const updateProfile = useCallback(
    (updates) => {
      if (!user) return;
      const updated = { ...user, ...updates };
      localStorage.setItem(AUTH_KEY, JSON.stringify(updated));
      setUser(updated);

      // Mettre à jour dans le "DB" mock
      const users = JSON.parse(localStorage.getItem(USERS_KEY) || '{}');
      if (users[user.email]) {
        users[user.email] = { ...users[user.email], ...updates };
        localStorage.setItem(USERS_KEY, JSON.stringify(users));
      }
    },
    [user]
  );

  // ── Décrémenter les analyses restantes ──
  const useAnalysis = useCallback(() => {
    if (!user) return false;
    if (user.plan === 'enterprise') return true; // Illimité
    if (user.analysesRemaining <= 0) return false;
    updateProfile({ analysesRemaining: user.analysesRemaining - 1 });
    return true;
  }, [user, updateProfile]);

  const value = {
    user,
    loading,
    isAuthenticated: !!user,
    signup,
    login,
    logout,
    updateProfile,
    useAnalysis,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

/**
 * Hook pour accéder au contexte d'authentification
 */
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth doit être utilisé dans un AuthProvider');
  }
  return context;
}

export default AuthContext;
