/**
 * ─────────────────────────────────────────
 * ContractShield — Design Tokens & Thème
 * ─────────────────────────────────────────
 * Toutes les couleurs, espacements et tokens
 * de design centralisés ici.
 */

export const theme = {
  // ── Surfaces ──
  bg:          '#0B0E14',
  surface:     '#12161F',
  surfaceAlt:  '#181D29',
  surfaceHover:'#1C2230',

  // ── Bordures ──
  border:       '#1E2533',
  borderActive: '#2A3344',

  // ── Texte ──
  text:      '#E8ECF4',
  textMuted: '#8892A5',
  textDim:   '#5A6478',

  // ── Accent principal (orange) ──
  accent:     '#FF6B35',
  accentDark: '#E85D2C',
  accentGlow: 'rgba(255, 107, 53, 0.15)',

  // ── Sémantique ──
  danger:      '#FF4757',
  dangerGlow:  'rgba(255, 71, 87, 0.12)',
  warning:     '#FFBE0B',
  warningGlow: 'rgba(255, 190, 11, 0.12)',
  success:     '#06D6A0',
  successGlow: 'rgba(6, 214, 160, 0.12)',
  info:        '#4EA8DE',
  infoGlow:    'rgba(78, 168, 222, 0.12)',

  // ── Niveaux de risque ──
  highRisk:    '#FF8C42',
  highRiskGlow:'rgba(255, 140, 66, 0.12)',

  // ── Typographie ──
  fontSerif: "'DM Serif Display', serif",
  fontSans:  "'DM Sans', sans-serif",
  fontMono:  "'JetBrains Mono', monospace",

  // ── Rayons de bordure ──
  radius: {
    sm: '8px',
    md: '12px',
    lg: '16px',
    xl: '20px',
    pill: '100px',
  },

  // ── Ombres ──
  shadow: {
    sm: '0 2px 8px rgba(0, 0, 0, 0.2)',
    md: '0 4px 16px rgba(0, 0, 0, 0.25)',
    lg: '0 8px 32px rgba(0, 0, 0, 0.3)',
    accent: '0 8px 30px rgba(255, 107, 53, 0.3)',
  },

  // ── Breakpoints ──
  breakpoint: {
    sm: '480px',
    md: '768px',
    lg: '1024px',
    xl: '1200px',
  },
};

/**
 * Niveaux de risque avec couleurs et labels
 */
export const RISK_LEVELS = {
  critical: {
    label: 'Critique',
    color: theme.danger,
    bg: theme.dangerGlow,
    icon: '🔴',
  },
  high: {
    label: 'Élevé',
    color: theme.highRisk,
    bg: theme.highRiskGlow,
    icon: '🟠',
  },
  medium: {
    label: 'Moyen',
    color: theme.warning,
    bg: theme.warningGlow,
    icon: '🟡',
  },
  low: {
    label: 'Faible',
    color: theme.success,
    bg: theme.successGlow,
    icon: '🟢',
  },
};

/**
 * Retourne la couleur du score selon la valeur
 */
export function getScoreColor(score) {
  if (score >= 70) return theme.success;
  if (score >= 40) return theme.warning;
  return theme.danger;
}

/**
 * Retourne le label du score selon la valeur
 */
export function getScoreLabel(score) {
  if (score >= 70) return 'Bon contrat';
  if (score >= 40) return 'Attention requise';
  return 'Contrat à risque';
}

export default theme;
