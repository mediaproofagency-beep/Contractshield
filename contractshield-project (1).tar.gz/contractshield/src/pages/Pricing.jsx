/**
 * Pricing — Page tarifs avec intégration Stripe
 * Affiche les 3 plans et gère le checkout
 */

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PLANS } from '@/data/plans';
import { createCheckoutSession, isStripeConfigured } from '@/utils/stripe';
import { useAuth } from '@/context/AuthContext';
import theme from '@/styles/theme';

export default function Pricing() {
  const navigate = useNavigate();
  const { isAuthenticated, updateProfile } = useAuth();
  const [loading, setLoading] = useState(null); // plan id en cours
  const [yearly, setYearly] = useState(false);

  const handleSubscribe = async (plan) => {
    // Si enterprise, rediriger vers contact
    if (plan.id === 'enterprise') {
      window.open('mailto:contact@contractshield.io?subject=Plan Enterprise', '_blank');
      return;
    }

    // Vérifier l'authentification
    if (!isAuthenticated) {
      navigate('/auth?redirect=pricing');
      return;
    }

    setLoading(plan.id);

    try {
      const result = await createCheckoutSession(plan.stripePriceId, plan.id);

      // Si mock (pas de Stripe configuré), simuler la souscription
      if (result) {
        updateProfile({
          plan: plan.id,
          analysesRemaining: plan.analysesPerMonth,
        });
        navigate('/analyze?subscribed=true');
      }
    } catch (err) {
      console.error('Erreur checkout:', err);
      alert(`Erreur: ${err.message}`);
    } finally {
      setLoading(null);
    }
  };

  return (
    <div
      style={{
        maxWidth: 1050,
        margin: '0 auto',
        padding: '60px 24px',
        animation: 'fadeIn 0.5s ease-out',
      }}
    >
      {/* Header */}
      <div style={{ textAlign: 'center', marginBottom: 20 }}>
        <h2
          style={{
            fontFamily: theme.fontSerif,
            fontSize: 'clamp(28px, 4vw, 36px)',
            marginBottom: 12,
          }}
        >
          Protégez-vous à votre{' '}
          <span style={{ color: theme.accent }}>juste prix</span>
        </h2>
        <p style={{ color: theme.textMuted, fontSize: 16 }}>
          Choisissez le plan adapté à vos besoins. Annulez à tout moment.
        </p>
      </div>

      {/* Toggle mensuel / annuel */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 12,
          marginBottom: 40,
        }}
      >
        <span style={{ fontSize: 14, color: !yearly ? theme.text : theme.textDim }}>
          Mensuel
        </span>
        <button
          onClick={() => setYearly(!yearly)}
          style={{
            width: 48,
            height: 26,
            borderRadius: 13,
            border: 'none',
            background: yearly ? theme.accent : theme.border,
            position: 'relative',
            cursor: 'pointer',
            transition: 'background 0.3s',
          }}
        >
          <div
            style={{
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: 'white',
              position: 'absolute',
              top: 3,
              left: yearly ? 25 : 3,
              transition: 'left 0.3s',
            }}
          />
        </button>
        <span style={{ fontSize: 14, color: yearly ? theme.text : theme.textDim }}>
          Annuel
        </span>
        {yearly && (
          <span
            className="tag"
            style={{
              background: theme.successGlow,
              color: theme.success,
              fontSize: 11,
            }}
          >
            -17%
          </span>
        )}
      </div>

      {/* Stripe mode info */}
      {!isStripeConfigured() && (
        <div
          style={{
            textAlign: 'center',
            marginBottom: 20,
            padding: '8px 16px',
            borderRadius: 8,
            background: theme.infoGlow,
            fontSize: 13,
            color: theme.info,
          }}
        >
          🔧 Mode démo — Les paiements sont simulés. Configurez vos clés Stripe dans .env pour les paiements réels.
        </div>
      )}

      {/* Plans */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: 20,
        }}
      >
        {PLANS.map((plan, i) => (
          <div
            key={plan.id}
            style={{
              background: theme.surface,
              border: `1px solid ${plan.popular ? theme.accent : theme.border}`,
              borderRadius: 18,
              padding: '32px 28px',
              transition: 'all 0.3s',
              position: 'relative',
              overflow: 'hidden',
              animation: `fadeIn 0.5s ease-out ${i * 0.12}s both`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-4px)';
              e.currentTarget.style.borderColor = plan.popular
                ? theme.accent
                : theme.borderActive;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)';
              e.currentTarget.style.borderColor = plan.popular
                ? theme.accent
                : theme.border;
            }}
          >
            {/* Top gradient for popular */}
            {plan.popular && (
              <div
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  height: 3,
                  background: `linear-gradient(90deg, ${theme.accent}, ${theme.accentDark})`,
                }}
              />
            )}

            {/* Badge populaire */}
            {plan.popular && (
              <div
                style={{
                  position: 'absolute',
                  top: 14,
                  right: 14,
                  background: theme.accentGlow,
                  color: theme.accent,
                  padding: '4px 10px',
                  borderRadius: 20,
                  fontSize: 11,
                  fontWeight: 700,
                }}
              >
                POPULAIRE
              </div>
            )}

            {/* Nom du plan */}
            <div
              style={{
                fontSize: 14,
                fontWeight: 600,
                color: theme.textMuted,
                marginBottom: 6,
              }}
            >
              {plan.name}
            </div>

            {/* Prix */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginBottom: 4 }}>
              <span style={{ fontFamily: theme.fontSerif, fontSize: 42 }}>
                {yearly ? plan.yearlyPrice : plan.price}€
              </span>
              <span style={{ color: theme.textDim, fontSize: 14 }}>{plan.period}</span>
            </div>
            <div
              style={{
                fontSize: 13,
                color: theme.textDim,
                marginBottom: 24,
              }}
            >
              {plan.description}
            </div>

            {/* CTA */}
            <button
              className={plan.popular ? 'btn-primary' : 'btn-ghost'}
              onClick={() => handleSubscribe(plan)}
              disabled={loading === plan.id}
              style={{
                width: '100%',
                marginBottom: 24,
                opacity: loading === plan.id ? 0.6 : 1,
              }}
            >
              {loading === plan.id ? (
                <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                  <span className="animate-spin" style={{ display: 'inline-block' }}>⏳</span>
                  Traitement...
                </span>
              ) : (
                plan.cta
              )}
            </button>

            {/* Features */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {plan.features.map((f, j) => (
                <div
                  key={j}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                    fontSize: 14,
                    color: theme.textMuted,
                  }}
                >
                  <span style={{ color: theme.success, fontSize: 14, flexShrink: 0 }}>✓</span>
                  {f}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* CTA contact */}
      <div
        style={{
          marginTop: 48,
          padding: 32,
          borderRadius: 16,
          background: theme.surface,
          border: `1px solid ${theme.border}`,
          textAlign: 'center',
        }}
      >
        <div style={{ fontFamily: theme.fontSerif, fontSize: 20, marginBottom: 8 }}>
          Besoin d'un plan sur mesure ?
        </div>
        <p style={{ color: theme.textMuted, fontSize: 14, marginBottom: 16 }}>
          Contactez notre équipe pour une offre adaptée à votre cabinet ou entreprise
        </p>
        <a href="mailto:contact@contractshield.io?subject=Plan sur mesure">
          <button className="btn-ghost">Prendre rendez-vous</button>
        </a>
      </div>
    </div>
  );
}
