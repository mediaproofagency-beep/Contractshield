/**
 * Home — Page d'accueil / Landing page
 */

import { Link } from 'react-router-dom';
import theme from '@/styles/theme';

const STATS = [
  { n: '12,847', label: 'Contrats analysés' },
  { n: '34,291', label: 'Clauses détectées' },
  { n: '€2.3M', label: 'Économisés pour nos clients' },
  { n: '98.7%', label: 'Précision de détection' },
];

const STEPS = [
  {
    icon: '📄',
    title: '1. Uploadez',
    desc: "Glissez votre contrat au format PDF, DOCX ou image. Notre IA extrait automatiquement le texte.",
  },
  {
    icon: '🧠',
    title: '2. Analyse IA',
    desc: 'Notre modèle juridique analyse chaque clause, identifie les risques et compare aux standards légaux.',
  },
  {
    icon: '✅',
    title: '3. Agissez',
    desc: "Recevez un rapport détaillé avec score de risque, alertes et suggestions de reformulation.",
  },
];

const TESTIMONIALS = [
  {
    name: 'Marie D.',
    role: 'Avocate indépendante',
    text: "ContractShield m'a fait gagner 3h par contrat. La détection des clauses abusives est bluffante.",
    score: 5,
  },
  {
    name: 'Thomas R.',
    role: 'DRH, startup SaaS',
    text: "On l'utilise pour vérifier tous nos contrats d'embauche. Indispensable.",
    score: 5,
  },
  {
    name: 'Sophie L.',
    role: 'Particulière',
    text: "J'ai découvert 3 clauses abusives dans mon bail que je n'aurais jamais vues seule. Merci !",
    score: 5,
  },
];

export default function Home() {
  return (
    <div style={{ animation: 'fadeIn 0.6s ease-out' }}>
      {/* ── Hero ── */}
      <section style={{ textAlign: 'center', padding: '72px 24px 56px', position: 'relative' }}>
        {/* Glow derrière */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 500,
            height: 500,
            borderRadius: '50%',
            background: `radial-gradient(circle, ${theme.accentGlow} 0%, transparent 70%)`,
            pointerEvents: 'none',
          }}
        />

        <div style={{ position: 'relative', zIndex: 1, maxWidth: 680, margin: '0 auto' }}>
          <span
            className="tag"
            style={{
              background: theme.accentGlow,
              color: theme.accent,
              marginBottom: 20,
              display: 'inline-block',
            }}
          >
            IA juridique de nouvelle génération
          </span>

          <h1
            style={{
              fontFamily: theme.fontSerif,
              fontSize: 'clamp(36px, 6vw, 56px)',
              lineHeight: 1.1,
              marginBottom: 20,
              letterSpacing: -1,
            }}
          >
            Ne signez plus
            <br />
            <span style={{ color: theme.accent }}>à l'aveugle</span>
          </h1>

          <p
            style={{
              fontSize: 'clamp(15px, 2vw, 18px)',
              color: theme.textMuted,
              maxWidth: 520,
              margin: '0 auto 36px',
              lineHeight: 1.65,
            }}
          >
            ContractShield analyse vos contrats en quelques secondes grâce à l'IA.
            Détection de clauses abusives, score de risque, et suggestions de reformulation.
          </p>

          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <Link to="/analyze">
              <button className="btn-primary" style={{ fontSize: 16, padding: '14px 36px' }}>
                Analyser un contrat →
              </button>
            </Link>
            <Link to="/pricing">
              <button className="btn-ghost" style={{ padding: '14px 28px' }}>
                Voir les tarifs
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Stats ── */}
      <section
        style={{
          display: 'flex',
          justifyContent: 'center',
          gap: 'clamp(24px, 4vw, 48px)',
          padding: '28px 24px',
          borderTop: `1px solid ${theme.border}`,
          borderBottom: `1px solid ${theme.border}`,
          background: theme.surface,
          flexWrap: 'wrap',
        }}
      >
        {STATS.map((s, i) => (
          <div key={i} style={{ textAlign: 'center', minWidth: 120 }}>
            <div style={{ fontFamily: theme.fontSerif, fontSize: 'clamp(22px, 3vw, 28px)', color: theme.accent }}>
              {s.n}
            </div>
            <div style={{ fontSize: 13, color: theme.textMuted, marginTop: 4 }}>{s.label}</div>
          </div>
        ))}
      </section>

      {/* ── Comment ça marche ── */}
      <section style={{ padding: '64px 24px', maxWidth: 1000, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 48 }}>
          <h2 style={{ fontFamily: theme.fontSerif, fontSize: 32, marginBottom: 12 }}>
            Comment ça marche
          </h2>
          <p style={{ color: theme.textMuted }}>
            Trois étapes simples pour protéger vos intérêts
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: 24,
          }}
        >
          {STEPS.map((step, i) => (
            <div
              key={i}
              className="glass"
              style={{
                borderRadius: 16,
                padding: 32,
                textAlign: 'center',
                animation: `fadeIn 0.6s ease-out ${i * 0.15}s both`,
              }}
            >
              <div style={{ fontSize: 40, marginBottom: 16 }}>{step.icon}</div>
              <div style={{ fontFamily: theme.fontSerif, fontSize: 20, marginBottom: 10 }}>
                {step.title}
              </div>
              <p style={{ fontSize: 14, color: theme.textMuted, lineHeight: 1.6 }}>
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Témoignages ── */}
      <section style={{ padding: '48px 24px', maxWidth: 1000, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: theme.fontSerif,
            fontSize: 28,
            textAlign: 'center',
            marginBottom: 36,
          }}
        >
          Ce qu'en disent nos utilisateurs
        </h2>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: 20,
          }}
        >
          {TESTIMONIALS.map((t, i) => (
            <div
              key={i}
              className="glass"
              style={{
                borderRadius: 14,
                padding: 24,
                animation: `fadeIn 0.5s ease-out ${i * 0.12}s both`,
              }}
            >
              <div style={{ marginBottom: 12, color: theme.warning }}>
                {'★'.repeat(t.score)}
              </div>
              <p
                style={{
                  fontSize: 14,
                  color: theme.textMuted,
                  lineHeight: 1.6,
                  marginBottom: 16,
                  fontStyle: 'italic',
                }}
              >
                "{t.text}"
              </p>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14 }}>{t.name}</div>
                <div style={{ fontSize: 12, color: theme.textDim }}>{t.role}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA Demo ── */}
      <section style={{ padding: '0 24px 64px', maxWidth: 1000, margin: '0 auto' }}>
        <div
          style={{
            padding: 48,
            borderRadius: 20,
            background: `linear-gradient(135deg, ${theme.surfaceAlt}, ${theme.surface})`,
            border: `1px solid ${theme.border}`,
            textAlign: 'center',
          }}
        >
          <h3 style={{ fontFamily: theme.fontSerif, fontSize: 26, marginBottom: 12 }}>
            🎯 Essayez gratuitement
          </h3>
          <p style={{ color: theme.textMuted, marginBottom: 28, maxWidth: 480, margin: '0 auto 28px' }}>
            Première analyse offerte. Voyez la puissance de ContractShield sur votre propre contrat.
          </p>
          <Link to="/analyze">
            <button className="btn-primary" style={{ fontSize: 16, padding: '14px 36px' }}>
              Lancer une analyse gratuite →
            </button>
          </Link>
        </div>
      </section>
    </div>
  );
}
