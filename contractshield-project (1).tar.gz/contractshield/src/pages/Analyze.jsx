/**
 * Analyze — Page d'upload et d'analyse de contrats
 * Gère le flux complet : upload → animation → résultats
 */

import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import UploadZone from '@/components/UploadZone';
import AnalyzingAnimation from '@/components/AnalyzingAnimation';
import AnalysisReport from '@/components/AnalysisReport';
import useAnalysis from '@/hooks/useAnalysis';
import { MOCK_ANALYSES } from '@/data/mockAnalyses';
import { analyzeContract, saveToHistory } from '@/api/mockBackend';
import theme from '@/styles/theme';

export default function Analyze() {
  const navigate = useNavigate();
  const {
    status,
    progress,
    report,
    error,
    startAnalysis,
    reset,
    isAnalyzing,
    isComplete,
  } = useAnalysis();

  // Upload d'un vrai fichier
  const handleFileSelect = useCallback(
    (file) => {
      startAnalysis(file);
    },
    [startAnalysis]
  );

  // Utiliser un contrat démo (crée un faux fichier)
  const handleDemoAnalysis = useCallback(
    (type) => {
      const demoNames = {
        employment: 'Contrat_CDI_Demo.pdf',
        rental: 'Bail_Location_Demo.pdf',
        commercial: 'CGV_Prestataire_Demo.pdf',
      };

      // Créer un faux fichier pour la démo
      const fakeFile = new File(
        ['contenu simulé du contrat'],
        demoNames[type] || 'contrat_demo.pdf',
        { type: 'application/pdf' }
      );

      startAnalysis(fakeFile);
    },
    [startAnalysis]
  );

  // Si l'analyse est terminée, afficher le rapport
  if (isComplete && report) {
    return <AnalysisReport report={report} onNewAnalysis={reset} />;
  }

  return (
    <div
      style={{
        maxWidth: 800,
        margin: '0 auto',
        padding: '48px 24px',
        animation: 'fadeIn 0.5s ease-out',
      }}
    >
      <h2 style={{ fontFamily: theme.fontSerif, fontSize: 30, marginBottom: 8 }}>
        Analyser un contrat
      </h2>
      <p style={{ color: theme.textMuted, marginBottom: 32 }}>
        Uploadez votre document pour une analyse complète par notre IA juridique
      </p>

      {/* ── Zone d'upload avec animation ── */}
      <div style={{ position: 'relative' }}>
        {isAnalyzing && <AnalyzingAnimation progress={progress} />}
        <UploadZone
          onFileSelect={handleFileSelect}
          disabled={isAnalyzing}
        />
      </div>

      {/* ── Message d'erreur ── */}
      {error && (
        <div
          style={{
            marginTop: 20,
            padding: '14px 20px',
            borderRadius: 12,
            background: theme.dangerGlow,
            border: `1px solid ${theme.danger}30`,
            color: theme.danger,
            fontSize: 14,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            animation: 'fadeIn 0.3s ease-out',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>⚠️</span>
            <span>{error}</span>
          </div>
          <button
            onClick={reset}
            style={{
              background: 'none',
              border: 'none',
              color: theme.danger,
              cursor: 'pointer',
              fontWeight: 600,
              fontFamily: theme.fontSans,
            }}
          >
            Réessayer
          </button>
        </div>
      )}

      {/* ── Contrats démo ── */}
      {!isAnalyzing && !isComplete && (
        <div style={{ marginTop: 48 }}>
          <h3
            style={{
              fontSize: 15,
              fontWeight: 600,
              marginBottom: 16,
              color: theme.textMuted,
            }}
          >
            Ou essayez avec un exemple :
          </h3>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
              gap: 12,
            }}
          >
            {[
              {
                icon: '📋',
                title: 'Contrat CDI',
                desc: 'Contrat de travail avec clauses à risque',
                type: 'employment',
              },
              {
                icon: '🏠',
                title: "Bail d'habitation",
                desc: "Bail de location avec points d'attention",
                type: 'rental',
              },
              {
                icon: '📑',
                title: 'CGV Prestataire',
                desc: 'Conditions générales commerciales',
                type: 'commercial',
              },
            ].map((demo) => (
              <div
                key={demo.type}
                className="glass"
                role="button"
                tabIndex={0}
                style={{
                  borderRadius: 12,
                  padding: 18,
                  cursor: 'pointer',
                  display: 'flex',
                  gap: 14,
                  alignItems: 'center',
                  transition: 'all 0.2s',
                }}
                onClick={() => handleDemoAnalysis(demo.type)}
                onKeyDown={(e) => e.key === 'Enter' && handleDemoAnalysis(demo.type)}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = theme.accent)}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = theme.border)}
              >
                <div style={{ fontSize: 28, flexShrink: 0 }}>{demo.icon}</div>
                <div>
                  <div style={{ fontWeight: 600, marginBottom: 2, fontSize: 14 }}>
                    {demo.title}
                  </div>
                  <div style={{ fontSize: 13, color: theme.textMuted }}>{demo.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
