/**
 * History — Historique des analyses
 */

import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getHistory, deleteFromHistory } from '@/api/mockBackend';
import { getScoreColor } from '@/styles/theme';
import theme from '@/styles/theme';

const TYPE_ICONS = {
  Emploi: '📋',
  Immobilier: '🏠',
  Commercial: '📑',
};

export default function History() {
  const [history, setHistory] = useState([]);

  useEffect(() => {
    setHistory(getHistory());
  }, []);

  const handleDelete = (id, e) => {
    e.stopPropagation();
    deleteFromHistory(id);
    setHistory(getHistory());
  };

  return (
    <div
      style={{
        maxWidth: 900,
        margin: '0 auto',
        padding: '48px 24px',
        animation: 'fadeIn 0.5s ease-out',
      }}
    >
      {/* Header */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 32,
          flexWrap: 'wrap',
          gap: 12,
        }}
      >
        <div>
          <h2 style={{ fontFamily: theme.fontSerif, fontSize: 28 }}>Historique</h2>
          <p style={{ color: theme.textMuted, fontSize: 14, marginTop: 4 }}>
            {history.length
              ? `${history.length} analyse(s) effectuée(s)`
              : 'Aucune analyse pour le moment'}
          </p>
        </div>
        <Link to="/analyze">
          <button className="btn-primary">+ Nouvelle analyse</button>
        </Link>
      </div>

      {/* Liste vide */}
      {history.length === 0 && (
        <div
          style={{
            textAlign: 'center',
            padding: 60,
            background: theme.surface,
            borderRadius: 16,
            border: `1px solid ${theme.border}`,
          }}
        >
          <div style={{ fontSize: 48, marginBottom: 16 }}>📂</div>
          <div
            style={{
              fontFamily: theme.fontSerif,
              fontSize: 20,
              marginBottom: 8,
            }}
          >
            Aucune analyse
          </div>
          <p style={{ color: theme.textMuted, marginBottom: 24, fontSize: 14 }}>
            Commencez par analyser votre premier contrat
          </p>
          <Link to="/analyze">
            <button className="btn-primary">Analyser un contrat →</button>
          </Link>
        </div>
      )}

      {/* Liste des analyses */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {history.map((h, i) => {
          const scoreColor = getScoreColor(h.score);
          return (
            <Link
              key={h.id}
              to="/analyze"
              style={{ textDecoration: 'none', color: 'inherit' }}
            >
              <div
                className="glass"
                style={{
                  borderRadius: 14,
                  padding: '18px 22px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  animation: `fadeIn 0.4s ease-out ${i * 0.08}s both`,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.borderColor = theme.borderActive)}
                onMouseLeave={(e) => (e.currentTarget.style.borderColor = theme.border)}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, minWidth: 0 }}>
                  <div
                    style={{
                      width: 42,
                      height: 42,
                      borderRadius: 10,
                      background: theme.surfaceAlt,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 20,
                      flexShrink: 0,
                    }}
                  >
                    {TYPE_ICONS[h.type] || '📄'}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div
                      style={{
                        fontWeight: 600,
                        marginBottom: 2,
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                      }}
                    >
                      {h.title}
                    </div>
                    <div style={{ fontSize: 13, color: theme.textDim }}>
                      {h.date} · {h.type}
                      {h.riskyCount > 0 && (
                        <span style={{ color: theme.danger, marginLeft: 8 }}>
                          {h.riskyCount} alerte(s)
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{ textAlign: 'right' }}>
                    <div
                      style={{
                        fontFamily: theme.fontMono,
                        fontSize: 20,
                        fontWeight: 700,
                        color: scoreColor,
                      }}
                    >
                      {h.score}
                    </div>
                    <div style={{ fontSize: 11, color: theme.textDim }}>/100</div>
                  </div>
                  <button
                    onClick={(e) => handleDelete(h.id, e)}
                    title="Supprimer"
                    style={{
                      background: 'none',
                      border: 'none',
                      color: theme.textDim,
                      cursor: 'pointer',
                      fontSize: 16,
                      padding: 4,
                      borderRadius: 6,
                      transition: 'color 0.2s',
                    }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = theme.danger)}
                    onMouseLeave={(e) => (e.currentTarget.style.color = theme.textDim)}
                  >
                    ✕
                  </button>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
