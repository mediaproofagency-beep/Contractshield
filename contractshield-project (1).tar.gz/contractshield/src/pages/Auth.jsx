/**
 * Auth — Page de connexion / inscription
 * Formulaire dual (login / signup) avec validation
 */

import { useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import LoadingSpinner from '@/components/common/LoadingSpinner';
import theme from '@/styles/theme';

export default function Auth() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const redirect = searchParams.get('redirect') || '/analyze';
  const { login, signup } = useAuth();

  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Validation basique
      if (!email || !password) {
        throw new Error('Veuillez remplir tous les champs.');
      }
      if (password.length < 6) {
        throw new Error('Le mot de passe doit faire au moins 6 caractères.');
      }
      if (mode === 'signup' && !name) {
        throw new Error('Veuillez entrer votre nom.');
      }

      if (mode === 'login') {
        await login(email, password);
      } else {
        await signup(email, password, name);
      }

      navigate(`/${redirect}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = {
    width: '100%',
    padding: '12px 16px',
    background: theme.surfaceAlt,
    border: `1px solid ${theme.border}`,
    borderRadius: 10,
    color: theme.text,
    fontSize: 15,
    fontFamily: theme.fontSans,
    outline: 'none',
    transition: 'border-color 0.2s',
  };

  return (
    <div
      style={{
        maxWidth: 440,
        margin: '0 auto',
        padding: '60px 24px',
        animation: 'fadeIn 0.5s ease-out',
      }}
    >
      {/* Logo */}
      <div style={{ textAlign: 'center', marginBottom: 36 }}>
        <Link
          to="/"
          style={{
            textDecoration: 'none',
            color: theme.text,
            display: 'inline-flex',
            alignItems: 'center',
            gap: 10,
          }}
        >
          <div
            style={{
              width: 40,
              height: 40,
              borderRadius: 10,
              background: `linear-gradient(135deg, ${theme.accent}, ${theme.accentDark})`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 20,
              color: 'white',
            }}
          >
            ⛨
          </div>
          <span style={{ fontFamily: theme.fontSerif, fontSize: 22 }}>
            ContractShield
          </span>
        </Link>
      </div>

      {/* Card */}
      <div
        style={{
          background: theme.surface,
          border: `1px solid ${theme.border}`,
          borderRadius: 18,
          padding: '36px 32px',
        }}
      >
        <h2
          style={{
            fontFamily: theme.fontSerif,
            fontSize: 24,
            marginBottom: 6,
            textAlign: 'center',
          }}
        >
          {mode === 'login' ? 'Connexion' : 'Créer un compte'}
        </h2>
        <p
          style={{
            color: theme.textMuted,
            fontSize: 14,
            textAlign: 'center',
            marginBottom: 28,
          }}
        >
          {mode === 'login'
            ? 'Accédez à votre espace ContractShield'
            : 'Commencez avec une analyse gratuite'}
        </p>

        {/* Error */}
        {error && (
          <div
            style={{
              padding: '10px 14px',
              borderRadius: 10,
              background: theme.dangerGlow,
              border: `1px solid ${theme.danger}30`,
              color: theme.danger,
              fontSize: 14,
              marginBottom: 20,
              animation: 'fadeIn 0.2s ease-out',
            }}
          >
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit}>
          {mode === 'signup' && (
            <div style={{ marginBottom: 16 }}>
              <label
                style={{
                  display: 'block',
                  fontSize: 13,
                  fontWeight: 500,
                  color: theme.textMuted,
                  marginBottom: 6,
                }}
              >
                Nom complet
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Jean Dupont"
                style={inputStyle}
                onFocus={(e) => (e.target.style.borderColor = theme.accent)}
                onBlur={(e) => (e.target.style.borderColor = theme.border)}
              />
            </div>
          )}

          <div style={{ marginBottom: 16 }}>
            <label
              style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 500,
                color: theme.textMuted,
                marginBottom: 6,
              }}
            >
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jean@example.com"
              style={inputStyle}
              onFocus={(e) => (e.target.style.borderColor = theme.accent)}
              onBlur={(e) => (e.target.style.borderColor = theme.border)}
              autoComplete="email"
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label
              style={{
                display: 'block',
                fontSize: 13,
                fontWeight: 500,
                color: theme.textMuted,
                marginBottom: 6,
              }}
            >
              Mot de passe
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              style={inputStyle}
              onFocus={(e) => (e.target.style.borderColor = theme.accent)}
              onBlur={(e) => (e.target.style.borderColor = theme.border)}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />
          </div>

          <button
            type="submit"
            className="btn-primary"
            disabled={loading}
            style={{
              width: '100%',
              padding: '14px',
              fontSize: 15,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
            }}
          >
            {loading ? (
              <>
                <LoadingSpinner size={18} color="white" />
                {mode === 'login' ? 'Connexion...' : 'Création...'}
              </>
            ) : mode === 'login' ? (
              'Se connecter'
            ) : (
              'Créer mon compte'
            )}
          </button>
        </form>

        {/* Switch mode */}
        <div
          style={{
            textAlign: 'center',
            marginTop: 20,
            fontSize: 14,
            color: theme.textMuted,
          }}
        >
          {mode === 'login' ? (
            <>
              Pas encore de compte ?{' '}
              <button
                onClick={() => { setMode('signup'); setError(null); }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: theme.accent,
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontFamily: theme.fontSans,
                  fontSize: 14,
                }}
              >
                S'inscrire
              </button>
            </>
          ) : (
            <>
              Déjà un compte ?{' '}
              <button
                onClick={() => { setMode('login'); setError(null); }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: theme.accent,
                  cursor: 'pointer',
                  fontWeight: 600,
                  fontFamily: theme.fontSans,
                  fontSize: 14,
                }}
              >
                Se connecter
              </button>
            </>
          )}
        </div>
      </div>

      {/* Demo hint */}
      <div
        style={{
          textAlign: 'center',
          marginTop: 24,
          padding: 14,
          borderRadius: 10,
          background: theme.surfaceAlt,
          fontSize: 13,
          color: theme.textDim,
        }}
      >
        💡 Mode démo : utilisez n'importe quel email/mot de passe pour tester.
      </div>
    </div>
  );
}
