/**
 * ─────────────────────────────────────────
 * ContractShield — App Principal
 * ─────────────────────────────────────────
 * Routing, layout global, et providers
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/context/AuthContext';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';

// Pages
import Home from '@/pages/Home';
import Analyze from '@/pages/Analyze';
import History from '@/pages/History';
import Pricing from '@/pages/Pricing';
import Auth from '@/pages/Auth';

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <Header />

          <main style={{ flex: 1 }}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/analyze" element={<Analyze />} />
              <Route path="/history" element={<History />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/auth" element={<Auth />} />

              {/* 404 */}
              <Route
                path="*"
                element={
                  <div
                    style={{
                      textAlign: 'center',
                      padding: '80px 24px',
                    }}
                  >
                    <div style={{ fontSize: 64, marginBottom: 16 }}>🔍</div>
                    <h2
                      style={{
                        fontFamily: "'DM Serif Display', serif",
                        fontSize: 28,
                        marginBottom: 8,
                      }}
                    >
                      Page introuvable
                    </h2>
                    <p style={{ color: '#8892A5', marginBottom: 24 }}>
                      La page que vous cherchez n'existe pas.
                    </p>
                    <a href="/">
                      <button className="btn-primary">Retour à l'accueil</button>
                    </a>
                  </div>
                }
              />
            </Routes>
          </main>

          <Footer />
        </div>
      </Router>
    </AuthProvider>
  );
}
