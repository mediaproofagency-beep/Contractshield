/**
 * ─────────────────────────────────────────
 * ContractShield — Stripe Integration
 * ─────────────────────────────────────────
 * Gère l'initialisation de Stripe et la
 * création de sessions de paiement.
 *
 * En mode développement (sans clé Stripe),
 * simule les paiements via localStorage.
 */

import { loadStripe } from '@stripe/stripe-js';

// ── Initialisation Stripe ───────────────────

const STRIPE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;

/**
 * Instance Stripe (lazy-loaded)
 * Retourne null si aucune clé n'est configurée
 */
let stripePromise = null;

export function getStripe() {
  if (!STRIPE_KEY) {
    console.warn(
      '[ContractShield] Clé Stripe non configurée. Mode simulation activé.'
    );
    return null;
  }
  if (!stripePromise) {
    stripePromise = loadStripe(STRIPE_KEY);
  }
  return stripePromise;
}

/**
 * Vérifie si Stripe est configuré
 */
export function isStripeConfigured() {
  return !!STRIPE_KEY;
}

// ── Simulation de paiement (dev) ────────────

const SUBSCRIPTION_KEY = 'contractshield_subscription';

/**
 * Simule un abonnement en mode développement
 * @param {string} planId - ID du plan (starter, professional, enterprise)
 * @returns {Promise<Object>}
 */
export async function mockSubscribe(planId) {
  // Simule un délai de traitement
  await new Promise((r) => setTimeout(r, 1500));

  const subscription = {
    id: `sub_mock_${Date.now()}`,
    planId,
    status: 'active',
    createdAt: new Date().toISOString(),
    currentPeriodEnd: new Date(
      Date.now() + 30 * 24 * 60 * 60 * 1000
    ).toISOString(),
  };

  localStorage.setItem(SUBSCRIPTION_KEY, JSON.stringify(subscription));
  return subscription;
}

/**
 * Récupère l'abonnement actuel (simulé)
 * @returns {Object|null}
 */
export function getCurrentSubscription() {
  try {
    const raw = localStorage.getItem(SUBSCRIPTION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Annule l'abonnement (simulé)
 */
export function cancelSubscription() {
  localStorage.removeItem(SUBSCRIPTION_KEY);
}

// ── Checkout réel Stripe ────────────────────

/**
 * Redirige vers Stripe Checkout pour un abonnement
 * En mode dev sans clé, simule l'abonnement
 *
 * @param {string} priceId - Stripe Price ID
 * @param {string} planId - ID interne du plan
 * @returns {Promise<void>}
 */
export async function createCheckoutSession(priceId, planId) {
  const stripe = getStripe();

  // Mode simulation si Stripe non configuré
  if (!stripe) {
    console.log(`[Mock] Simulation abonnement plan: ${planId}`);
    return mockSubscribe(planId);
  }

  // Mode réel : Stripe Checkout
  const stripeInstance = await stripe;

  /**
   * NOTE: En production, cet appel devrait passer par votre
   * backend pour créer une session Checkout sécurisée :
   *
   * const response = await fetch('/api/create-checkout-session', {
   *   method: 'POST',
   *   headers: { 'Content-Type': 'application/json' },
   *   body: JSON.stringify({ priceId, planId }),
   * });
   * const { sessionId } = await response.json();
   */

  const { error } = await stripeInstance.redirectToCheckout({
    lineItems: [{ price: priceId, quantity: 1 }],
    mode: 'subscription',
    successUrl: `${window.location.origin}/analyze?subscribed=true`,
    cancelUrl: `${window.location.origin}/pricing?canceled=true`,
  });

  if (error) {
    throw new Error(error.message);
  }
}

export default {
  getStripe,
  isStripeConfigured,
  createCheckoutSession,
  mockSubscribe,
  getCurrentSubscription,
  cancelSubscription,
};
