/**
 * ─────────────────────────────────────────
 * ContractShield — File Validation Utils
 * ─────────────────────────────────────────
 */

/** Taille max : 20 Mo */
export const MAX_FILE_SIZE = 20 * 1024 * 1024;

/** MIME types acceptés */
export const ACCEPTED_TYPES = {
  'application/pdf': ['.pdf'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'application/msword': ['.doc'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
};

/** Extensions pour affichage */
export const ACCEPTED_EXTENSIONS = ['PDF', 'DOCX', 'DOC', 'JPG', 'PNG'];

/**
 * Formate une taille de fichier en unité lisible
 * @param {number} bytes
 * @returns {string}
 */
export function formatFileSize(bytes) {
  if (bytes === 0) return '0 o';
  const units = ['o', 'Ko', 'Mo', 'Go'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}

/**
 * Vérifie si un fichier est un type accepté
 * @param {File} file
 * @returns {boolean}
 */
export function isAcceptedType(file) {
  if (ACCEPTED_TYPES[file.type]) return true;
  const ext = '.' + file.name.split('.').pop().toLowerCase();
  return Object.values(ACCEPTED_TYPES).flat().includes(ext);
}
