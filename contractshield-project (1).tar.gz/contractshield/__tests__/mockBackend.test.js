/**
 * ─────────────────────────────────────────
 * ContractShield — Tests unitaires
 * ─────────────────────────────────────────
 * Tests pour le backend simulé
 *
 * Lancer : npm run test
 */

import { describe, it, expect, beforeEach } from 'vitest';

// Note: en environnement Vitest, les imports avec @ alias
// nécessitent la config vite. On utilise des chemins relatifs ici.
// En pratique, configurez vitest.config.js avec le même alias.

// ── Tests de validation de fichier ──

describe('validateFile', () => {
  // Mock de la fonction (simplifié pour le test)
  const MAX_SIZE = 20 * 1024 * 1024;
  const ACCEPTED = ['.pdf', '.docx', '.doc', '.jpg', '.jpeg', '.png'];

  function validateFile(file) {
    if (!file) return { valid: false, error: 'Aucun fichier fourni.' };
    if (file.size > MAX_SIZE) return { valid: false, error: 'Fichier trop volumineux.' };
    if (file.size === 0) return { valid: false, error: 'Le fichier est vide ou corrompu.' };
    const ext = '.' + file.name.split('.').pop().toLowerCase();
    if (!ACCEPTED.includes(ext)) return { valid: false, error: 'Extension non supportée.' };
    return { valid: true };
  }

  it('rejette un fichier null', () => {
    const result = validateFile(null);
    expect(result.valid).toBe(false);
    expect(result.error).toContain('Aucun fichier');
  });

  it('rejette un fichier vide', () => {
    const result = validateFile({ name: 'test.pdf', size: 0, type: 'application/pdf' });
    expect(result.valid).toBe(false);
    expect(result.error).toContain('vide');
  });

  it('rejette un fichier trop volumineux', () => {
    const result = validateFile({ name: 'big.pdf', size: 25 * 1024 * 1024, type: 'application/pdf' });
    expect(result.valid).toBe(false);
    expect(result.error).toContain('volumineux');
  });

  it('rejette un format non supporté', () => {
    const result = validateFile({ name: 'test.exe', size: 1000, type: 'application/exe' });
    expect(result.valid).toBe(false);
    expect(result.error).toContain('non supportée');
  });

  it('accepte un PDF valide', () => {
    const result = validateFile({ name: 'contrat.pdf', size: 5000, type: 'application/pdf' });
    expect(result.valid).toBe(true);
  });

  it('accepte un DOCX valide', () => {
    const result = validateFile({ name: 'contrat.docx', size: 8000, type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
    expect(result.valid).toBe(true);
  });

  it('accepte une image JPG', () => {
    const result = validateFile({ name: 'scan.jpg', size: 2000, type: 'image/jpeg' });
    expect(result.valid).toBe(true);
  });
});

// ── Tests de l'analyse de contrat ──

describe('analyzeContract (mock)', () => {
  // Simulation simplifiée de analyzeContract
  async function mockAnalyze(file) {
    if (!file) throw new Error('Aucun fichier fourni');
    if (file.size === 0) throw new Error('Le fichier est vide ou corrompu.');

    const score = Math.floor(Math.random() * 60) + 20;
    return {
      title: `Analyse - ${file.name}`,
      score,
      clauses: [
        { id: 1, title: 'Clause test', risk: 'high', article: 'Art. 1' },
      ],
      stats: {
        totalClauses: 10,
        riskyCount: 1,
        pagesAnalyzed: 5,
        timeSeconds: 3.2,
      },
    };
  }

  it('retourne un rapport avec un score entre 20 et 80', async () => {
    const file = { name: 'test.pdf', size: 5000, type: 'application/pdf' };
    const report = await mockAnalyze(file);
    expect(report.score).toBeGreaterThanOrEqual(20);
    expect(report.score).toBeLessThanOrEqual(80);
  });

  it('retourne un titre contenant le nom du fichier', async () => {
    const file = { name: 'mon_contrat.pdf', size: 5000, type: 'application/pdf' };
    const report = await mockAnalyze(file);
    expect(report.title).toContain('mon_contrat.pdf');
  });

  it('retourne des clauses non vides', async () => {
    const file = { name: 'test.pdf', size: 5000, type: 'application/pdf' };
    const report = await mockAnalyze(file);
    expect(report.clauses.length).toBeGreaterThan(0);
  });

  it('retourne des stats valides', async () => {
    const file = { name: 'test.pdf', size: 5000, type: 'application/pdf' };
    const report = await mockAnalyze(file);
    expect(report.stats.totalClauses).toBeGreaterThan(0);
    expect(report.stats.timeSeconds).toBeGreaterThan(0);
  });

  it('rejette un fichier null', async () => {
    await expect(mockAnalyze(null)).rejects.toThrow('Aucun fichier');
  });

  it('rejette un fichier vide', async () => {
    await expect(
      mockAnalyze({ name: 'empty.pdf', size: 0, type: 'application/pdf' })
    ).rejects.toThrow('vide');
  });
});

// ── Tests du scoring ──

describe('Score calculation', () => {
  function getScoreLabel(score) {
    if (score >= 70) return 'Bon contrat';
    if (score >= 40) return 'Attention requise';
    return 'Contrat à risque';
  }

  it('identifie un bon contrat (score >= 70)', () => {
    expect(getScoreLabel(85)).toBe('Bon contrat');
    expect(getScoreLabel(70)).toBe('Bon contrat');
  });

  it('identifie un contrat nécessitant attention (40-69)', () => {
    expect(getScoreLabel(55)).toBe('Attention requise');
    expect(getScoreLabel(40)).toBe('Attention requise');
  });

  it('identifie un contrat à risque (< 40)', () => {
    expect(getScoreLabel(20)).toBe('Contrat à risque');
    expect(getScoreLabel(39)).toBe('Contrat à risque');
  });
});
